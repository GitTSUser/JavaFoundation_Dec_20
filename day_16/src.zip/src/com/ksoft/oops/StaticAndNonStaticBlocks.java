package com.ksoft.oops;

import java.util.Scanner;

class Account {

	private static String bankName;
	private long acntNo;
	private String holderName;
	private double amount;
	private int age;
	private double roi;
	private String acntStatus;
	private static long accountGenerator = 123456;
	static {
		bankName = "ABC Bank";
	}

	{ // non-static block
		acntNo = accountGenerator++;
		acntStatus = "Active";
	}

	public Account(String holderName, double amount, int age) {
		this.holderName = holderName;
		this.amount = amount;
		this.age = age;

		if (this.age > 15 && this.age <= 25) {
			this.roi = 2.00;
		} else if (this.age > 25 && this.age <= 50) {
			this.roi = 3.00;
		} else {
			this.roi = 4.00;
		}
	}

	public String accountInfo() {
		return bankName + " " + this.acntNo + " " + this.holderName + " " + this.amount + " " + this.age + " "
				+ this.roi + " " + this.acntStatus;
	}
}

public class StaticAndNonStaticBlocks {

	private static Account[] generateAccounts(int n) {
		Account[] accounts = new Account[n];
		Scanner scanner = new Scanner(System.in);
		String name;
		double amount;
		int age;
		for (int i = 0; i < n; i++) {
			System.out.println("enter account " + (i + 1) + " details:");
			System.out.println("enter your name:");
			name = scanner.next();
			System.out.println("enter amount:");
			amount = scanner.nextDouble();
			System.out.println("enter your age:");
			age = scanner.nextInt();

			Account account = new Account(name, amount, age);
			accounts[i] = account;
		}
		return accounts;
	}

	public static void main(String[] args) {

		Account accounts[] = generateAccounts(4);

		System.out.println("---Account Details-----");

		for (int i = 0; i < accounts.length; i++) {
			System.out.println(accounts[i].accountInfo());
		}

	}
}