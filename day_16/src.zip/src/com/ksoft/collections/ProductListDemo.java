package com.ksoft.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

class Product implements Comparable<Product> {
	private int id;
	private String name;
	private double price;
	private String category;
	private int qty;
	private String manufacturer;

	public Product(int id, String name, double price, String category, int qty, String manufacturer) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.category = category;
		this.qty = qty;
		this.manufacturer = manufacturer;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + ", category=" + category + ", qty=" + qty
				+ ", manufacturer=" + manufacturer + "]";
	}

	// implementation of natural ordering by comparing product IDs
	@Override
	public int compareTo(Product pr) {
		Product p1 = this;
		Product p2 = pr;

		int id1 = p1.getId();
		int id2 = p2.getId();

		if (id1 < id2) {
			return -1;
		} else if (id1 > id2) {
			return 1;
		}
		return 0;

	}
}

class NamedComparator implements Comparator<Product> {

	@Override
	public int compare(Product p1, Product p2) {

		String name1 = p1.getName();
		String name2 = p2.getName();

		int result = name1.compareTo(name2);
		return result;
	}

}

class CategoryComparator implements Comparator<Product> {

	@Override
	public int compare(Product p1, Product p2) {

		String category1 = p1.getCategory();
		String category2 = p2.getCategory();

		int result = category1.compareTo(category2);

		return result;
	}

}

class PriceComparator implements Comparator<Product> {

	@Override
	public int compare(Product p1, Product p2) {

		double price1 = p1.getPrice();
		double price2 = p2.getPrice();

		if (price1 < price2) {
			return -1;
		} else if (price1 > price2) {
			return 1;
		}

		return 0;
	}

}

public class ProductListDemo {

	private static void loadProducts(ArrayList<Product> prodList) {
		Product p1 = new Product(1, "fan", 2500.25, "electronics", 5, "crompton");
		Product p2 = new Product(2, "chair", 3500.25, "furniture", 12, "royal-oak");
		Product p3 = new Product(6, "mobile", 12500.25, "electronics", 11, "motorola");
		Product p4 = new Product(8, "shirt", 1500.75, "textile", 6, "raymonds");
		Product p5 = new Product(7, "oven", 22500.25, "electronics", 8, "LG");
		Product p6 = new Product(5, "sofa", 35500.25, "furniture", 7, "BKP");
		Product p7 = new Product(4, "tv", 32500.25, "electronics", 2, "sony");
		Product p8 = new Product(3, "lappy", 55000.25, "electronics", 5, "lenovo");

		prodList.addAll(Arrays.asList(p1, p2, p3, p4, p5, p6, p7, p8));
	}

	private static void displayProducts(ArrayList<Product> prodList) {
		System.out.println("----Products in List----");
		for (Product product : prodList) {
			System.out.println(product); // this will invoke toString() method from Product class
		}
	}

	// increase price of each product by 20% and return the list

	private static ArrayList<Product> increasePriceForEachProduct(ArrayList<Product> prodList) {

		for (int i = 0; i < prodList.size(); i++) {
			Product p = prodList.get(i); // got product obj
			double price = p.getPrice(); // got price from product obj
			price = price + (0.2 * price); // updating price by 20 percent
			p.setPrice(price); // updating price property in product obj
		}
		return prodList;
	}

	public static void main(String[] args) {

		ArrayList<Product> productList = new ArrayList<Product>();
		loadProducts(productList);
		displayProducts(productList);

		ArrayList<Product> resultList = increasePriceForEachProduct(productList);
		System.out.println("--------after updating price , list is-------");
		displayProducts(resultList);

		System.out.println("-------after sorting by id, list is------");
		Collections.sort(productList); // naturally by product id
		displayProducts(productList);
		System.out.println("------after sorting by name, list is----");
		Collections.sort(productList, new NamedComparator());
		displayProducts(productList);

		System.out.println("------after sorting by price, list is----");
		Collections.sort(productList, new PriceComparator());
		displayProducts(productList);

		System.out.println("------after sorting by category, list is----");
		Collections.sort(productList, new CategoryComparator());
		displayProducts(productList);
	}
}