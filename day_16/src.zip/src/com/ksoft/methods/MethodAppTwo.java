//program to demonstrate method calling

package com.ksoft.methods;

public class MethodAppTwo {

	static void usa() {
		lanka();
		System.out.println("i am from usa");
	}

	static void lanka() {
		System.out.println("i am from srilanka");
		india();
	}

	static void india() {
		System.out.println("i am from India");
	}

	public static void main(String[] args) {
		usa();
		System.out.println("main ends");
	}
}