package com.ksoft.demo;

import java.util.List;

import com.ksoft.demo.entity.Project;
import com.ksoft.demo.service.IProjectService;
import com.ksoft.demo.service.ProjectServiceImpl;

public class ProjectClient {

	private static IProjectService projectService = new ProjectServiceImpl();

	public static void main(String[] args) {

		/*
		 * Project project = new Project(125, "MS", "Rail-Road", 7, "Varun");
		 * projectService.add(project);
		 */

		List<Project> projectList = projectService.getAllProjects();

		for (Project p : projectList) {
			System.out.println(p);
		}

	}

}
