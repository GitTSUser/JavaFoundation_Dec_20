//program to demo creating generic class that has 2 parameter types
package com.ksoft.generics;

class MyGenericWorld<T, U> {

	private T one;
	private U two;

	public MyGenericWorld(T one, U two) {
		this.one = one;
		this.two = two;
	}

	public T getOne() {
		return this.one;
	}

	public U getTwo() {
		return this.two;
	}
}

public class GenericClassDemo2 {

	public static void main(String[] args) {

		MyGenericWorld<Integer, String> mgw = new MyGenericWorld<Integer, String>(1001, "Hyderabad");

		System.out.println("id is:" + mgw.getOne());
		System.out.println("name is:" + mgw.getTwo());

		MyGenericWorld<String, String> countryCapital = new MyGenericWorld<String, String>("India", "Delhi");

		System.out.println("country is:" + countryCapital.getOne());
		System.out.println("capital is:" + countryCapital.getTwo());
	}
}