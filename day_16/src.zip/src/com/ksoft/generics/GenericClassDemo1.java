//program to demo creation of generic class and using it
package com.ksoft.generics;

class GenericWorld<T> {

	private T data;

	public GenericWorld(T data) {
		this.data = data;
	}

	public T getData() {
		return this.data;
	}
}

public class GenericClassDemo1 {

	public static void main(String[] args) {

		/*
		 * GenericWorld gw = new GenericWorld(120);
		 * 
		 * GenericWorld gw2 = new GenericWorld(140);
		 * 
		 * System.out.println("int value is:" + gw.getData());
		 * 
		 * System.out.println("int value is:" + gw2.getData());
		 * 
		 * int first = (Integer) gw.getData(); int second = (Integer) gw2.getData(); int
		 * result = first + second;
		 * 
		 * System.out.println("sum is:" + result);
		 */

		GenericWorld<Integer> gw = new GenericWorld<Integer>(120);

		GenericWorld<Integer> gw2 = new GenericWorld<Integer>(150);

		System.out.println("int value is:" + gw.getData());
		System.out.println("int value is:" + gw2.getData());

		int result = gw.getData() + gw2.getData();

		System.out.println("sum is:" + result);

		GenericWorld<String> gw3 = new GenericWorld<String>("GenericWorld");

		System.out.println("what is:" + gw3.getData());

	}
}
