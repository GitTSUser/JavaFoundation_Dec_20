package com.ksoft.generics;

class GenericOperation {

	public static <T> T doAddition(T[] elements) {

		if (elements[0] instanceof Integer) { // verifies the element is Integer or not
			Integer sum = 0;
			for (T t : elements) {
				sum = (Integer) sum + (Integer) t;
			}
			return (T) sum;
		}

		if (elements[0] instanceof Double) { // verifies the ele is Double or not
			Double sum = 0.0;

			for (T t : elements) {
				sum = (Double) sum + (Double) t;
			}

			return (T) sum;
		}

		if (elements[0] instanceof String) { // verifies the ele is String or not

			StringBuilder sum = new StringBuilder();
			for (T t : elements) {

				sum.append(t);
			}
			return (T) sum.toString();
		}

		return null;

	}

}

public class GenericMethodImplDemo5 {

	public static void main(String[] args) {

		String names[] = { "Sachin ", "Dravid ", "Kohli ", "Dhoni ", "Rohith " };

		System.out.println("Names:" + GenericOperation.doAddition(names));
		Integer arr[] = { 100, 200, 300, 400 };

		System.out.println("Num sum:" + GenericOperation.doAddition(arr));
	}
}
