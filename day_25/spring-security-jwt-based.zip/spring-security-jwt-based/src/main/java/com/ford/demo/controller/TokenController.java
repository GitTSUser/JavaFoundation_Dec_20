package com.ford.demo.controller;

import com.ford.demo.security.jwt.JwtTokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/tapi")
public class TokenController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserDetailsService userDetailsService;
    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @PostMapping("/login")
    public Map<String,String> getToken(@RequestBody User user) {
        String username = user.getUsername();
        String password = user.getPassword();
        log.info("Token requested by {}  and {}",username,password);
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));

        UserDetails userDetails=userDetailsService.loadUserByUsername(username);

        String token=jwtTokenUtil.generateToken(username);

        Map<String,String> response=new HashMap<>();
        response.put("token",token);

        return  response;
    }
}
