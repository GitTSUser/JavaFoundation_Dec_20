//program to demonstrate using "throws" clause to throw checked exception
package com.ksoft.exception;

public class UsingThrowsClauseApp {

	private static void method3() throws InterruptedException {

		for (int i = 1; i <= 10; i++) {
			if (i == 5) {
				throw new InterruptedException("loop interrrupted");
			} else {
				System.out.println("i is:" + i);
			}
		}
	}

	private static void method2() throws InterruptedException {
		method3();
	}

	private static void method1() throws InterruptedException {
		method2();
	}

	public static void main(String[] args) throws InterruptedException {
		try {
			method1();
		} catch (InterruptedException ie) {
			System.out.println("exception is:" + ie.getMessage());
		}
		System.out.println("program ends");
	}
}