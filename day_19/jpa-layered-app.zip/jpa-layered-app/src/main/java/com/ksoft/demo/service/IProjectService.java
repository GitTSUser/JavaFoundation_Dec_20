package com.ksoft.demo.service;

import java.util.List;

import com.ksoft.demo.entity.Project;

public interface IProjectService {

	public Project add(Project project);

	public Project update(Project project);

	public boolean delete(int projectId);

	public Project getProject(int projectId);

	public List<Project> getAllProjects();

}
