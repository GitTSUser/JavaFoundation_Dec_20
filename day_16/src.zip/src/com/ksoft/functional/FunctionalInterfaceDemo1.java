//program to demo creation and implementation of functional interface
package com.ksoft.functional;

@FunctionalInterface
interface Greetable {
	public abstract void greet(String personName);
}

public class FunctionalInterfaceDemo1 {

	public static void main(String[] args) {

		Greetable g = (personName) -> {
			System.out.println("Good Morning " + personName);
		};

		g.greet("SreeHitha");

	}
}
