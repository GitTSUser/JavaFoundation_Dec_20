//find out how-many are eligible to Vote by implementing Votable interface using lambda
package com.ksoft.functional;

@FunctionalInterface
interface Votable {

	public abstract int isEligible(int ages[]);

}

public class FindPersonsAreEligibleToVoteDemo3 {

	public static void main(String[] args) {

		Votable v = (ages) -> {

			int count = 0;
			for (int age : ages) {
				if (age >= 18) {
					count++;
				}
			}

			return count;
		};

		int eligibleCount = v.isEligible(new int[] { 25, 20, 36, 12, 17, 16 });

		System.out.println("eligible to vote are:" + eligibleCount);

	}
}
