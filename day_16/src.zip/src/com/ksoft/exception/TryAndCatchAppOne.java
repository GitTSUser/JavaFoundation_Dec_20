//program  to demonstrate  handle exceptions using try and catch
package com.ksoft.exception;

import java.util.Scanner;

public class TryAndCatchAppOne {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int a;
		int b;
		int c;
		try {
		System.out.println("enter value for a:");
		a = scanner.nextInt();
		System.out.println("enter another for b:");
		b = scanner.nextInt();

		c = a / b;

		System.out.println("a/b is:" + c);
		}catch(ArithmeticException ae) {
			
			System.out.println("exception is:" + ae.getMessage());
		}
		scanner.close();
		System.out.println("program ends");
	}
}