//program to demo multiple inheritance
package com.ksoft.inheritance;

class AA {

	int x = 10;
}

class BB {
	int x = 100;
}

//class CC extends AA extends BB {
class CC extends AA {
	public void printInfo() {
		System.out.println("x is:" + x);
	//	System.out.println("y is:" + y);
	}

}

public class MultipleInheritanceDemo {

	public static void main(String[] args) {

		CC obj = new CC();
		obj.printInfo();
	}

}
