package com.ksoft.app.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ksoft.app.entity.Item;

@Repository
public interface IItemRepository extends CrudRepository<Item, Integer> {

	/*
	 * @Query("select i from Item i where i.name=:itemName") public Item
	 * getItem(@Param("itemName") String name);
	 * 
	 * @Query("select i from Item i where i.name=:name and i.category=:cat") public
	 * List<Item> getItemByNameAndCategory(@Param("name")String name,@Param("cat")
	 * String cat);
	 */

	public Item findItemByName(String name);

	public List<Item> findItemByNameAndCategory(String name, String category);

	public List<Item> findItemByPrice(double price);

}
