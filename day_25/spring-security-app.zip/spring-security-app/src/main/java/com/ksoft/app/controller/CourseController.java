package com.ksoft.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ksoft.app.model.Course;
import com.ksoft.app.service.ICourseService;

@RestController
@RequestMapping("/api")
public class CourseController {

	@Autowired
	private ICourseService courseService;

	@PostMapping("/add-course")
	public Course addCourse(@RequestBody Course course) {
		return courseService.addNewCourse(course);
	}

	@GetMapping("/one-course/{courseId}")
	public Course getSingleCourse(@PathVariable("courseId") Integer cId) {
		return courseService.getSingleCourse(cId);
	}

	@GetMapping("/all-courses")
	public List<Course> getAllCourses() {
		return courseService.getAllCourses();
	}

	@DeleteMapping("/delete")
	public String deleteCourse(@RequestParam("courseId") Integer cId) {
		if (courseService.deleteCourse(cId)) {
			return "Course with id" + cId + " deleted";
		}
		return "Course is not found to delete";
	}
	
	@PutMapping("/update-course")
	public Course updateCourse(@RequestBody Course course) {
		return courseService.updateCourse(course);
	}
}