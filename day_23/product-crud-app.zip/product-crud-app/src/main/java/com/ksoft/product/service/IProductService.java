package com.ksoft.product.service;

import java.util.List;

import com.ksoft.product.model.Product;

public interface IProductService {
	
	public Product saveProduct(Product product);
	public Product updateProduct(Product product);
	public Product findProduct(int productId);
	public List<Product> findAllProducts();
	public boolean  removeProduct(int productId);

}
