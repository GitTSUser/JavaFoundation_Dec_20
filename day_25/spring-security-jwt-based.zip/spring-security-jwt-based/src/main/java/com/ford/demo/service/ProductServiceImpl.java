package com.ford.demo.service;

import com.ford.demo.model.Product;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductServiceImpl implements IProductService{

    private static List<Product> productList;

    static{
        productList = new ArrayList<Product>();
        productList.add(new Product(100,"fan",2500.50,12));
        productList.add(new Product(200,"chair",4500.50,22));
        productList.add(new Product(300,"table",5500.50,32));
        productList.add(new Product(400,"cup",7500.50,52));
    }
    @Override
    public Product addProduct(Product product) {
         productList.add(product);
         return product;
    }

    @Override
    public Product getProduct(int id) {

        for (Product product : productList) {
            if (product.getId() == id) {
                return product;
            }
        }

        return null;
    }

    @Override
    public List<Product> getAllProducts() {
        return productList;
    }

    @Override
    public Product updateProduct(Product product) {
        return productList.set(product.getId(), product);
    }

    @Override
    public String deleteProduct(int id) {
     productList.remove(getProduct(id));
     return "Product deleted";
    }
}
