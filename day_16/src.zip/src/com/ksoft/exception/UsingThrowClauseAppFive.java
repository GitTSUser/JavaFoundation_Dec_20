//program to demonstrate  using throw clause
package com.ksoft.exception;

class Person {
	private String name;
	private int age;

	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public String personInfo() {
		return this.name + " " + this.age;
	}

	public int getAge() {
		return this.age;
	}

	public String getName() {
		return this.name;
	}
}

public class UsingThrowClauseAppFive {

	private static void findEligibleToVote(Person personArr[]) {

		for (int i = 0; i < personArr.length; i++) {

			Person person = personArr[i]; // getting one person obj from array
			try {
				if (person == null) {
					throw new NullPointerException("person object has null value!");
				}
			} catch (NullPointerException npe) {
				System.out.println("exception is:" + npe.getMessage());
				continue;
			}
			int age = person.getAge(); // getting age from person obj
			String name = person.getName(); // getting name from person obj

			if (age > 18) { // verifying the age of the person
				System.out.println(name + " is eligible to vote");
			} else {
				System.out.println(name + " is not eligible to vote");
			}
		}
	}

	public static void main(String[] args) {

		Person p1 = new Person("harshini", 34);
		Person p2 = new Person("harshitha", 35);
		// Person p3 = new Person("hasini", 16);
		Person p3 = null;
		Person p4 = null;
		Person p5 = new Person("hrudaya", 45);

		Person persons[] = { p1, p2, p3, p4, p5 };

		findEligibleToVote(persons);
	}
}