package com.ksoft.constructors;

class Account {
	long accountNo;
	String holderName;
	double balance;
	String branch;

	Account(long accountNo, String holderName, double balance, String branch) { // added constructor
		this.accountNo = accountNo;
		this.holderName = holderName;
		this.balance = balance;
		this.branch = branch;
	}

	void deposit(double amount) { // business method
		this.balance += amount;
		System.out.println("after deposit, balance is:" + this.balance);
	}

	void withdraw(double amount) { // business method
		this.balance -= amount;
		System.out.println("after withdraw, balance is:" + this.balance);
	}

	void transfer(long accountNo, double amount) { // business method
		this.balance -= amount;
		System.out.println("after transfer, balance is:" + this.balance);
	}

	double getBalance() { // business method
		return this.balance;
	}
}

public class Customer {

	public static void main(String[] args) {

		Account account = new Account(123456, "Arun", 4500.25, "Kokapet");

		System.out.println(account.accountNo + " " + account.holderName + " " + account.balance);
		account.deposit(5000.25);
		account.withdraw(4000.50);
		account.transfer(245689, 2500);

		System.out.println("balance is:" + account.getBalance());

	}
}