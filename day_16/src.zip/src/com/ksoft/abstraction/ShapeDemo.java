//program to draw different shapes
package com.ksoft.abstraction;

abstract class Shape {

	private String name;
	private int sides;

	public Shape(String name, int sides) {
		this.name = name;
		this.sides = sides;
	}

	public abstract void draw(); // abstract method

	public String shapeInfo() { // concrete method
		return this.name + " has " + this.sides + " sides";
	}
}

class Rectangle extends Shape {

	public Rectangle(String name, int sides) {
		super(name, sides);
	}

	@Override
	public void draw() {
		System.out.println("drawing rectangle::" + super.shapeInfo());
	}
}

class Triangle extends Shape {

	public Triangle(String name, int sides) {
		super(name, sides);
	}

	@Override
	public void draw() {
		System.out.println("drawing triangle::" + super.shapeInfo());
	}
}

public class ShapeDemo {

	public static void main(String[] args) {

		Triangle triangle = new Triangle("right angle", 3);
		triangle.draw();

		Rectangle rectangle = new Rectangle("just", 4);
		rectangle.draw();
	}
}