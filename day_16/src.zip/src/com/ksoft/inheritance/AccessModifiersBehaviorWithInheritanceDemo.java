package com.ksoft.inheritance;

class A {
	private int x = 100;
	protected double y = 200.23;
	String z = "abc";
	public char g = 'A';

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}
}

class B extends A {

}

class C extends B {

}

public class AccessModifiersBehaviorWithInheritanceDemo {

	public static void main(String[] args) {

		/*
		 * B b = new B();
		 * 
		 * System.out.println("x is:" + b.getX()); // private member is not visible
		 * System.out.println("y is:" + b.y); System.out.println("z is:" + b.z);
		 * System.out.println("g is:" + b.g);
		 */
		C c = new C();

		System.out.println("x is:" + c.getX()); // private member is not visible
		System.out.println("y is:" + c.y);
		System.out.println("z is:" + c.z);
		System.out.println("g is:" + c.g);

	}

}
