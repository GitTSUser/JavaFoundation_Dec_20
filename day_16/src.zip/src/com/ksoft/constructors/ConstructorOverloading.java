//program to demonstrate constructor overloading
package com.ksoft.constructors;

class Employ {

	private int id;
	private String name;
	private double salary;
	private String role;
	private String emailId;

	public Employ() {
	}

	public Employ(int id) {
		this();
		this.id = id;
	}

	public Employ(int id, String name) {
		this(id);
		this.name = name;
	}

	public Employ(int id, String name, double salary) {
		this(id, name);
		this.salary = salary;
	}

	public Employ(int id, String name, double salary, String role) {
		this(id, name, salary);
		this.role = role;
	}

	public Employ(int id, String name, double salary, String role, String emailId) {
		this(id, name, salary, role);
		this.emailId = emailId;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String toString() {
		return this.id + " " + this.name + " " + this.salary + " " + this.role + " " + this.emailId;
	}
}

public class ConstructorOverloading {

	public static void main(String[] args) {

		// invokes 3 arg constructor
		Employ emp = new Employ(12345, "arun kumar", 45000.25);

		System.out.println("employ info:" + emp.toString());

		emp.setRole("Java Developer"); // updating the object
		emp.setEmailId("arun@yahoo.com");

		System.out.println("employ info:" + emp.toString());

	}
}
