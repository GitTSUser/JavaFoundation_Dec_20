package com.ksoft.methods;

class Operation {

	static void add(int a, int b) {
		System.out.println("addition is:" + (a + b));
	}

	static void sub(int a, int b) {
		System.out.println("sub is:" + (a - b));
	}
}

class Animal {

	void eat() {
		System.out.println("animal eats");
	}

	void sleep() {
		System.out.println("animal sleeps");
	}

}

public class MethodAppFive {

	public static void main(String[] args) {

		Operation.add(10, 20);

		Operation.sub(200, 100);

		Animal a=new Animal(); //object created
		
		a.eat();
		a.sleep();

	}
}
