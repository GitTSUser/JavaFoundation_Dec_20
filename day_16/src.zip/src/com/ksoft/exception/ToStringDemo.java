//program to demonstrate toString() method overriding
package com.ksoft.exception;

class Pupil extends Object {

	String name;
	int age;

	public Pupil(String name, int age) {
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return this.name + " " + this.age;
	}
}

public class ToStringDemo {
	public static void main(String[] args) {
		Pupil p = new Pupil("Swathi", 12);
		System.out.println("Pupil info:" + p.toString());
		System.out.println("Pupil info:" + p);
	}
}