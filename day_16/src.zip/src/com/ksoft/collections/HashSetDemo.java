package com.ksoft.collections;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;

public class HashSetDemo {

	private static void addCity(HashSet<String> cities, String city) {
		cities.add(city);
		System.out.println(city + " is added into HashSet");
	}

	private static void addAllCities(HashSet<String> cities, String[] cityArr) {
		cities.addAll(Arrays.asList(cityArr));
		System.out.println(cityArr.length + " cities added into HashSet");
	}

	private static void displayAllCities(HashSet<String> cities) {
		/*
		 * for (String city : cities) { System.out.println("city is:" + city); }
		 */
		System.out.println("-----cities are----");
		Iterator<String> cityIterator = cities.iterator();

		while (cityIterator.hasNext()) {
			System.out.println("city:" + cityIterator.next());
		}
	}

	public static void main(String[] args) {
		HashSet<String> citySet = new HashSet<String>();
		addCity(citySet, "Hyderabad");
		addCity(citySet, "Nizamabad");

		String cities[] = { "Hyderabad", "SR nagar", "LB nagar", "Bharath nagar", "Chanda nagar" };
		addAllCities(citySet, cities);
		displayAllCities(citySet);
	}
}