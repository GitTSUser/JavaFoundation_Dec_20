package com.ksoft.demo.dao;

import java.util.List;

import com.ksoft.demo.entity.Project;
import com.ksoft.demo.util.EntityManagerUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

@PersistenceContext
public class ProjectDaoImpl implements IProjectDao {

	private static EntityManager entityManager = EntityManagerUtil.getEntityManagerObject();

	public Project addProject(Project project) {

		entityManager.getTransaction().begin();
		entityManager.persist(project);
		entityManager.getTransaction().commit();
		System.out.println("one project saved in DB");

		return project;

	}

	public Project updateProject(Project project) {

		int projectId = project.getId(); // retreiving project id

		Project retreivedProject = getProject(projectId); // find the project from db

		if (retreivedProject == null) {
			System.out.println("the given project is not present in DB");
			return null;
		}
		// updating all fields
		retreivedProject.setName(project.getName());
		retreivedProject.setDomain(project.getDomain());
		retreivedProject.setManager(project.getManager());
		retreivedProject.setTeamSize(project.getTeamSize());

		entityManager.getTransaction().begin();
		entityManager.merge(retreivedProject);
		entityManager.getTransaction().commit();
		System.out.println("project updated successfully!");

		return retreivedProject;
	}

	public boolean deleteProject(int projectId) {

		Project existedProject = getProject(projectId);

		if (existedProject != null) {
			entityManager.getTransaction().begin();
			entityManager.remove(existedProject);
			entityManager.getTransaction().commit();
			System.out.println("project removed from DB");
			return true;
		}

		System.out.println("proejct is not found in DB");
		return false;
	}

	public Project getProject(int projectId) {

		Project p = entityManager.find(Project.class, projectId);

		return p;
	}

	public List<Project> getAllProjects() {
		final String SELECT_QUERY = "select p from Project p";

		TypedQuery<Project> query = entityManager.createQuery(SELECT_QUERY, Project.class);

		List<Project> projects = query.getResultList();

		return projects;

	}

}
