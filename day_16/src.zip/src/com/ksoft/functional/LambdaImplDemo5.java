//program to demo passing  a Lambda expression as an argument to another method
package com.ksoft.functional;
import java.util.Arrays;
import java.util.List;

@FunctionalInterface
interface EligibilityPredict {
	public abstract boolean isEligible(int age);
}
public class LambdaImplDemo5 {
	private static int countEligibleVoters(List<Integer> ageList, EligibilityPredict ep) {
		int cnt = 0;
		for (int age : ageList) {
			if (ep.isEligible(age)) {
				cnt++;
			}
		}
		return cnt;
	}

	public static void main(String[] args) {

		List<Integer> ageList = Arrays.asList(19, 20, 22, 37, 12, 17);
		int count = countEligibleVoters(ageList, (age) -> age >= 18);
		System.out.println("no.of citizen eligible to vote:" + count);
	}
}