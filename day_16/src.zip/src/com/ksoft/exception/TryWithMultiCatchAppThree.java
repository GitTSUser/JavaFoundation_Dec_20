//program to demonstrate a try with multiple catch blocks
package com.ksoft.exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TryWithMultiCatchAppThree {

	public static void main(String[] args) {

		Scanner scanner = null;
		try {
			scanner = new Scanner(System.in);
			System.out.println("enter a number:");
			int x = scanner.nextInt();
			System.out.println("enter another:");
			int y = scanner.nextInt();
			int z = x / y;
			System.out.println("division is:" + z);
		} catch (ArithmeticException ae) {
			System.out.println("exception is:" + ae.getMessage());
		} catch (InputMismatchException imme) {
			System.out.println("exception is::" + imme.getMessage());
		}

		System.out.println("program ends");
		scanner.close();

	}
}
