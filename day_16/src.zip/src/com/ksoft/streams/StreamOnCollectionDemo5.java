//program to demo performing stream operations on collection
package com.ksoft.streams;

import java.util.ArrayList;
import java.util.List;

public class StreamOnCollectionDemo5 {
	
	public static void main(String[] args) {
		
		
		List<Integer>  numList=new ArrayList<>();
		
		
		
		
		
		
		
	}

}
