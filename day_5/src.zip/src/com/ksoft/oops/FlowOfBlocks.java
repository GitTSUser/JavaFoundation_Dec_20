package com.ksoft.oops;

public class FlowOfBlocks {

	// static block
	static {
		System.out.println("static block-1");
	}

	{ // non-static block
		System.out.println("non-static block");
	}

	public FlowOfBlocks() { // constructor block

		System.out.println("constructor block");

	}

	public static void main(String[] args) { // static method block

		System.out.println("main method");

		FlowOfBlocks obj = new FlowOfBlocks();

		FlowOfBlocks obj2 = new FlowOfBlocks();

		FlowOfBlocks obj3 = new FlowOfBlocks();

	}

	static {
		System.out.println("static block-2");
	}

}
