//program to demo placing interfaces, abstract class and concrete classes in an app
package com.ksoft.inheritance;

interface IAnimal {

	int eyes = 2;

	void eat();

	void sleep();

	void move();
}

abstract class AbstractAnimal implements IAnimal {

	String name;
	int age;

	@Override
	public void eat() {
		System.out.println("animal eats food");
	}

	@Override
	public void sleep() {
		System.out.println("animal sleeps");
	}

	public String animalInfo() {

		return this.name + " " + this.age + "  " + eyes;
	}
}

class Puppy extends AbstractAnimal {

	public Puppy(String name, int age) {
		this.name = name;
		this.age = age;
	}

	@Override
	public void move() {
		System.out.println("moves on legs");
	}
}

class StarFish extends AbstractAnimal {

	public StarFish(String name, int age) {
		this.name = name;
		this.age = age;
	}

	@Override
	public void move() {
		System.out.println("swims in water");
	}
}

class Snake extends AbstractAnimal {

	public Snake(String name, int age) {
		this.name = name;
		this.age = age;
	}

	@Override
	public void move() {
		System.out.println("crawls on ground");
	}
}

public class RelationshipBetweenInterfaceAbstractAndConcrete {

	public static void main(String[] args) {
		StarFish fish = new StarFish("Ruby", 250);
		// fish.eat();
		// fish.sleep();
		// fish.move();
		fish.animalInfo();

		Snake snake = new Snake("Python", 20);
		// snake.eat();
		// snake.sleep();
		// snake.move();
		snake.animalInfo();

	}
}