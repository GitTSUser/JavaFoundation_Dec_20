//program to demo parameterized constructor  will initialize objects with diff values.

package com.ksoft.constructors;

class Food {
	// properties
	int code;
	String name;
	String type;
	double price;

	// parameterized constructor

	Food(int code, String name, String type, double price) {
		this.code = code;
		this.name = name;
		this.type = type;
		this.price = price;
	}
}

public class ParameterizedConstructor {

	public static void main(String[] args) {

		Food food = new Food(1234, "Biryani", "Non-Veg", 140.25);

		System.out.println(food.code + " " + food.name + " " + food.type + " " + food.price);

		Food anotherFood = new Food(2345, "Pizza", "Veg", 300.25);

		System.out.println(anotherFood.code + " " + anotherFood.name + " " + anotherFood.type + " " + anotherFood.price);
	}
}