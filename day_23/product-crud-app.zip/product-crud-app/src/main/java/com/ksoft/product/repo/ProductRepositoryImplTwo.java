package com.ksoft.product.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ksoft.product.model.Product;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;

@Repository
public class ProductRepositoryImplTwo implements IProductRepository {

	@Autowired
	private EntityManager entityManager;

	@Transactional
	@Override
	public Product addProduct(Product product) {
		entityManager.persist(product);
		System.out.println("product is saved in DB");
		return product;
	}

	@Override
	public Product getProduct(int productId) {
		Product p = entityManager.find(Product.class, productId);

		if (p != null) {
			System.out.println("product found with given id:" + productId);
		} else {
			System.out.println("product not found with given id");
		}
		return p;
	}

	@Transactional
	
	@Override
	public Product updateProduct(Product product) {

		Product p = getProduct(product.getId());

		if (p != null) {
			p.setName(product.getName());
			p.setPrice(product.getPrice());

			entityManager.merge(p);
			System.out.println("product is updated");
			return p;
		} else {
			System.out.println("product is not found to update");
		}

		return null;
	}

	@Override
	public List<Product> getAllProducts() {
		TypedQuery<Product> typedQuery = entityManager.createQuery(
				"select p from Product p", Product.class);
		List<Product> productList = typedQuery.getResultList();
		return productList;
	}

	
	@Transactional
	@Override
	public boolean deleteProduct(int productId) {

		Product p = getProduct(productId);

		if (p != null) {
			entityManager.remove(p);
			System.out.println("product is deleted from DB");
			return true;
		}

		System.out.println("product is not found in DB");
		return false;
	}
}