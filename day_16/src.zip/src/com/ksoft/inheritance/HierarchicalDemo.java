package com.ksoft.inheritance;

class Animal {

	private int legs;
	private int weight;
	private int height;

	public Animal(int legs, int weight, int height) {
		this.legs = legs;
		this.weight = weight;
		this.height = height;
	}

	public String animalInfo() {
		return this.legs + " " + this.weight + " " + this.height;
	}

}

class Dog extends Animal {

	private String name;
	private String breed;

	public Dog(int legs, int weight, int height, String name, String breed) {
		super(legs, weight, height); // invokes parent class constructor
		this.name = name;
		this.breed = breed;
	}

	public String dogInfo() {
		// super.animalInfo() invokes parent class method
		return super.animalInfo() + " " + this.name + " " + this.breed;
	}
}

class Lion extends Animal {

	private String name;

	public Lion(int legs, int weight, int height, String name) {
		super(legs, weight, height); // invokes parent class constructor
		this.name = name;
	}

	public String lionInfo() {
		return super.animalInfo() + " " + this.name;
	}

}
public class HierarchicalDemo {

	public static void main(String[] args) {

		Dog dog = new Dog(4, 25, 2, "Spiky", "Golden-Retriever");
		System.out.println(dog.dogInfo());

		Lion lion = new Lion(4, 240, 4, "mufasa");
		System.out.println(lion.lionInfo());
	}
}