//program to demonstrate the use of + operator
package com.ksoft.basics;

public class PlusOperator {

	public static void main(String[] args) {

		int x = 100;
		int y = 200;
		String msg = "sum of x,y is:";
		System.out.println(msg + x + y);
		System.out.println(msg + (x + y));

	}
}
