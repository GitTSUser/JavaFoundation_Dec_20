package com.ksoft.app.service;

import java.util.List;

import com.ksoft.app.entity.Item;

public interface IItemService {

	public Item saveItem(Item item);

	public Item updateItem(Item item);

	public Item getItem(int itemId);

	public List<Item> getAllItems();

	public boolean removeItem(int itemId);

	public Item findItem(String itemName);

	public List<Item> findItems(String itemName, String category);
	
	public List<Item> findItem(double price);

}
