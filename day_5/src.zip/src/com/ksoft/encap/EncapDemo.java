//program to demo need for encapsulation
package com.ksoft.encap;

class Student {

	// properties
	private int rollNo;
	private String name;
	private String branch;
	private char gender;
	private int age;
	private String emailId;

	// setter methods
	public void setRollNo(int rollNo) {

		if (rollNo >= 100 && rollNo <= 200) {
			this.rollNo = rollNo;
		} else {
			System.out.println("given roll no is invalid");
			throw new IllegalArgumentException("Given roll no not allowed!");
		}

	}

	public void setName(String name) {
		this.name = name;
	}

	public void setBranch(String branch) {

		String branches[] = { "CSE", "IT", "CIVIL", "MECH", "EEE", "ECE" };

		for (String b : branches) {
			if (b.equals(branch)) {
				this.branch = branch;
				return;
			}
		}

		System.out.println("invalid branch is given");

	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public void setAge(int age) {
		if (age > 18 && age <= 45) {
			this.age = age;
		} else {
			System.out.println("invalid age");
		}
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	// getter methods
	public int getRollNo() {
		return this.rollNo;
	}

	public String getName() {
		return this.name;
	}

	public String getBranch() {
		return this.branch;
	}

	public int getAge() {
		return this.age;
	}

	public String getEmailId() {
		return this.emailId;
	}

}

public class EncapDemo {

	public static void main(String[] args) {

		Student s = new Student();
		// s.rollNo = -12345;
		s.setRollNo(-12345);
		// s.name = "Bhavana";
		s.setName("Bhavana");
		// s.branch = "AEE";
		s.setBranch("AEE");
		// s.gender = 'f';
		s.setGender('F');
		// s.age = 140;
		s.setAge(140);
		// s.emailId = "bhavana@yho.com";
		s.setEmailId("bhavana@yho.com");

		System.out.println(
				s.getRollNo() + " " + s.getName() + " " + s.getBranch() + " " + s.getAge() + " " + s.getEmailId());

	}
}