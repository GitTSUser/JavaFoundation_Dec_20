//program to interchange the first and last letters of a string

package com.ksoft.methods;

import java.util.Arrays;

public class MethodAppFour {

	//first method
	static String[] interchangeFirstAndLast(String names[]) {
		for (int i = 0; i < names.length; i++) {
			String currentName = names[i];
			char first = currentName.charAt(0);
			char last = currentName.charAt(currentName.length() - 1);
			String middle = currentName.substring(1, currentName.length() - 1);
			names[i] = new String(last + middle + first);
		}

		return names;
	}

	//second method
	static void swap(char arr[], char first, char last) {

		arr[0] = last;
		arr[arr.length - 1] = first;
	}

	public static String[] swapFirstAndLast(String names[]) {

		for (int i = 0; i < names.length; i++) {

			char current[] = names[i].toCharArray();
			swap(current, current[0], current[current.length - 1]);
			names[i] = new String(current);
		}
		return names;
	}

	public static void main(String[] args) {

		String names[] = { "arun", "thaman", "charan", "karan" };

		//String updatedNames[] = interchangeFirstAndLast(names);
		String updatedNames[]=swapFirstAndLast(names);
		System.out.println(Arrays.toString(updatedNames));
	}
}