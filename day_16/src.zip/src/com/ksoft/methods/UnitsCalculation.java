package com.ksoft.methods;

import java.util.*;

public class UnitsCalculation {
	public static void main(String args[]) {
		Scanner s = new Scanner(System.in);
		double d[] = new double[5];
		for (int i = 0; i < d.length; i++) {
			d[i] = s.nextDouble();
		}
		double r[] = new double[5];
		for (int i = 0; i < d.length; i++) {
			if (d[i] > 1 && d[i] <= 40) {
				r[i] = d[i] * 2;
			} else if (d[i] > 40 && d[i] <= 60) {
				double rem = (d[i] - 40);
				r[i] = (40 * 2.50) + (rem * 3);
			} else if (d[i] > 60 && d[i] <= 80) {
				double rem = (d[i] - 60);
				r[i] = (40 * 3) + (20 * 5) + (rem * 5);
			} else if (d[i] > 80 && d[i] <= 100) {
				double rem = (d[i] - 80);
				r[i] = (40 * 4) + (20 * 5) + (20 * 6) + (rem * 7);
			} else {
				r[i] = d[i] * 8;
			}
		}
		for (int i = 0; i < r.length; i++) {
			System.out.println(r[i]);
		}
	}
}