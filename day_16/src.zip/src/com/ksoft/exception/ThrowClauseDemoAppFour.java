//program to demonstrate handling exception manually using "throw" clause
package com.ksoft.exception;

import java.util.Scanner;

public class ThrowClauseDemoAppFour {

	private static void method2(int m, int n) {
		try {
			if (n == 0) {
				throw new ArithmeticException("y value must be non-zero");
			}
			int z = m / n;
			System.out.println("division is:" + z);
		} catch (ArithmeticException ae) {
			System.out.println("exception is:" + ae.getMessage());
			throw ae; // re-throwing exception object to the caller
		}

	}

	private static void method1(int a, int b) {
		method2(a, b);
	}

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("enter a number:");
		int x = scanner.nextInt();
		System.out.println("enter another:");
		int y = scanner.nextInt();
		try {
			method1(x, y);
		} catch (ArithmeticException ae) {
			System.out.println("exception caught in main:" + ae.getMessage());
		}
		System.out.println("program ends");
		scanner.close();
	}
}