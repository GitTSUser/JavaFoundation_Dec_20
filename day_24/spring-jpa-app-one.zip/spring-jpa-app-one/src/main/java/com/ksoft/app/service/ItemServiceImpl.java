package com.ksoft.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ksoft.app.entity.Item;
import com.ksoft.app.repo.IItemRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ItemServiceImpl implements IItemService {

	@Autowired
	private IItemRepository itemRepository;

	@Override
	public Item saveItem(Item item) {
		itemRepository.save(item);
		log.info("item saved in DB");
		return item;
	}

	@Override
	public Item updateItem(Item item) {
		itemRepository.save(item);
		log.info("item updated in DB");
		return item;
	}

	@Override
	public Item getItem(int itemId) {
		Optional<Item> optionalItem = itemRepository.findById(itemId);
		if (optionalItem.isPresent()) {
			return optionalItem.get();
		} else {
			log.info("item not found");
		}
		return null;
	}

	@Override
	public List<Item> getAllItems() {

		Iterable<Item> items = itemRepository.findAll();

		List<Item> itemList = new ArrayList<>();

		for (Item i : items) {
			itemList.add(i);
		}

		return itemList;
	}

	@Override
	public boolean removeItem(int itemId) {

		if (getItem(itemId) != null) {

			itemRepository.deleteById(itemId);
			return true;
		} else {
			log.info("item not found to delete");
		}
		return false;
	}

	@Override
	public Item findItem(String itemName) {
		// Item item = itemRepository.getItem(itemName);
		Item item = itemRepository.findItemByName(itemName);
		return item;
	}

	@Override
	public List<Item> findItems(String itemName, String category) {
		// return itemRepository.getItemByNameAndCategory(itemName, category);
		return itemRepository.findItemByNameAndCategory(itemName, category);
	}

	@Override
	public List<Item> findItem(double price) {

		return itemRepository.findItemByPrice(price);
	}
}