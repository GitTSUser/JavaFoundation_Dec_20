package com.ksoft.demo.util;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class EntityManagerUtil {

	private static EntityManager entityManager;

	public static EntityManager getEntityManagerObject() {

		if (entityManager == null) {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("ProjectPU");
			entityManager = emf.createEntityManager();
		}

		return entityManager;
	}

}
