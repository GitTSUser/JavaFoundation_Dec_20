package com.ksoft.product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCrudAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
