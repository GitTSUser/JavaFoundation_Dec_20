package com.ksoft.demo.dao;

import java.util.List;

import com.ksoft.demo.entity.Project;

public interface IProjectDao {

	public Project addProject(Project project);

	public Project updateProject(Project project);

	public boolean deleteProject(int projectId);

	public Project getProject(int projectId);

	public List<Project> getAllProjects();

}
