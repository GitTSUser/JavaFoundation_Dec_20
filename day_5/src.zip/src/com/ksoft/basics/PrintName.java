//program to print your name and address
package com.ksoft.basics;

public class PrintName {

	public static void main(String ar[]) {

		System.out.println("\"K. Kiran Kumar\"");
		
		
	}

}
