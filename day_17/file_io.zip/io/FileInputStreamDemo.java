//program to read data from File using FileInputStream

package com.ksoft.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class FileInputStreamDemo {

	public static void main(String[] args) {

		FileInputStream fis = null;
		try {
			File file = new File(
	"E:\\C_Training2025\\JavaFound\\JavaFoundationApp"
	       + "\\src\\com\\ksoft\\io\\FileInputStreamDemo.java");

			fis = new FileInputStream(file);
			int ch = 0;
			StringBuffer content = new StringBuffer();

			while ((ch = fis.read()) != -1) {
				content.append((char) ch);
			}
			
			System.out.println("content is:" + content);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}