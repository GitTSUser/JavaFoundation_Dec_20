//program to demo creation of object and updation of object
package com.ksoft.oops;

class Employ {
	// properties of employ
	int id;
	String name;
	String role;
	double salary;
}

public class AppTwo {

	public static void main(String[] args) {

		Employ emp = new Employ();
		emp.id = 1234;
		emp.name = "Avila";
		emp.role = "Trainee";
		emp.salary = 26000;

		System.out.println("employ id:" + emp.id);
		System.out.println("employ name:" + emp.name);
		System.out.println("employ role:" + emp.role);
		System.out.println("employ salary:" + emp.salary);

		emp.role = "Java Developer";
		emp.salary = 56000;

		System.out.println("-----after updating role and salary---");

		System.out.println("employ id:" + emp.id);
		System.out.println("employ name:" + emp.name);
		System.out.println("employ role:" + emp.role);
		System.out.println("employ salary:" + emp.salary);
	}
}
