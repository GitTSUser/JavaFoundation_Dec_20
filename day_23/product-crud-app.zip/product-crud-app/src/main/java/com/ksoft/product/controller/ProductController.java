package com.ksoft.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ksoft.product.model.Product;
import com.ksoft.product.service.IProductService;

@RestController
@RequestMapping("/api")
public class ProductController {

	@Autowired
	private IProductService productService;

	@RequestMapping(path = "/products", method = RequestMethod.GET)
	public List<Product> retrieveAllProducts() {
		return productService.findAllProducts();
	}

	@RequestMapping(path = "/add-product", method = RequestMethod.POST)
	public Product addNewProduct(@RequestBody Product product) {
		return productService.saveProduct(product);
	}

	@RequestMapping(path = "/update-product", method = RequestMethod.PUT)
	public Product updateProduct(@RequestBody Product product) {
		return productService.updateProduct(product);
	}

	@RequestMapping(path = "/find-product/{productId}", method = RequestMethod.GET)
	public Product retrieveProduct(@PathVariable("productId") Integer productId) {
		return productService.findProduct(productId);
	}

	@RequestMapping(path = "/delete-product/{productId}", method = RequestMethod.DELETE)
	public String removeProduct(@PathVariable("productId") Integer productId) {
		if (productService.removeProduct(productId)) {
			return "Product removed successfully";
		}
		return "Product not removed";
	}
}