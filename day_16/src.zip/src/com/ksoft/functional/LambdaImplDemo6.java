//program to demo passing lambda expression as an argument to another method
package com.ksoft.functional;

@FunctionalInterface
interface Countable {
	int vowelCount(String city);
}

public class LambdaImplDemo6 {
	private static int countVowels(String city, Countable countable) {
		return countable.vowelCount(city);
	}

	public static void main(String[] args) {
		int vowelCount = countVowels("Hyderabad", (city) -> {
			int cnt = 0;
			for (int i = 0; i < city.length(); i++) {
				char letter = city.charAt(i);
		if (letter == 'a' || letter == 'e' || letter == 'i' || letter == 'o' || letter == 'u') {
					cnt++;
				}
			}
			return cnt;
		});

		System.out.println("Hyderabad has " + vowelCount + " vowels");
	}
}