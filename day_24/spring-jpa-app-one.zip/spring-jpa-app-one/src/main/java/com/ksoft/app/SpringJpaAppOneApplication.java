package com.ksoft.app;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.ksoft.app.entity.Item;
import com.ksoft.app.service.IItemService;

@SpringBootApplication
public class SpringJpaAppOneApplication implements CommandLineRunner {

	@Autowired
	private IItemService itemService;

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaAppOneApplication.class, args);
	}

	public void testAddItem() {

		Item item1 = new Item(123, "lappy", 55000.25, "electronics");
		Item item2 = new Item(124, "tv", 17000.25, "electronics");
		Item item3 = new Item(125, "mobile", 15000.25, "electronics");
		Item item4 = new Item(126, "pendrive", 230.25, "electronics");

		Item savedItem1 = itemService.saveItem(item1);
		Item savedItem2 = itemService.saveItem(item2);
		Item savedItem3 = itemService.saveItem(item3);
		Item savedItem4 = itemService.saveItem(item4);

		System.out.println("4-items saved in DB");

	}

	public void testFindItemById() {
		Item item = itemService.getItem(125);
		System.out.println("found item by id is::" + item);
	}

	public void testFindAllItems() {
		List<Item> items = itemService.getAllItems();
		System.out.println("---ALL ITEMS---");
		items.forEach(item -> System.out.println("Item is:" + item));
	}

	public void testFindItemByName() {

		Item i = itemService.findItem("tv");

		System.out.println("found item by name is:" + i);

	}

	@Override
	public void run(String... args) throws Exception {
		// testAddItem();
		testFindItemById();
		testFindAllItems();
		testFindItemByName();
		testFindItemByNameAndCategory();
		testFindItemByPrice();
	}

	private void testFindItemByPrice() {
		
		List<Item> itemList=itemService.findItem(17000.25);
		
		System.out.println("found item by price:"+itemList.get(0));
		
	}
	private void testFindItemByNameAndCategory() {

		List<Item> itemList = itemService.findItems("lappy", "electronics");
		System.out.println("items found is:" + itemList.get(0));
	}
}
