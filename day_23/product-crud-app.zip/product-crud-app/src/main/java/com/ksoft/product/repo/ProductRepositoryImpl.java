package com.ksoft.product.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.ksoft.product.model.Product;

@Repository
public class ProductRepositoryImpl implements IProductRepository {

	// productList collection acts as in-memory database
	private static List<Product> productList = new ArrayList<>();

	@Override
	public Product addProduct(Product product) {
		productList.add(product);
		return product;
	}

	@Override
	public Product getProduct(int productId) {

		return productList.stream().filter(p -> p.getId() == productId).findAny().get();

	}

	@Override
	public Product updateProduct(Product product) {
		Optional<Product> productToUpdate = productList.stream().filter(p -> p.getId() == product.getId()).findFirst();

		productToUpdate.ifPresent(p -> {
			p.setId(product.getId());
			p.setName(product.getName());
			p.setPrice(product.getPrice());
			p.setCategory(product.getCategory());
		});

		return productToUpdate.get();
	}

	@Override
	public List<Product> getAllProducts() {
		return productList;
	}

	@Override
	public boolean deleteProduct(int productId) {
		return productList.removeIf(p -> p.getId() == productId);
	}
}