//program to demo the calling of no-arg constructor 
// no-arg constructor initialize any object with same values.
package com.ksoft.constructors;

class Dog {

	// properties
	String name;
	String breed;
	int legs;
	String color;

	// constructor
	public Dog() {
		name = "Skuby";
		breed = "Husky";
		legs = 4;
		color = "BlackAndWhite";

		System.out.println("constructor called");
	}

}

public class ConstructorDemo {

	public static void main(String[] args) {

		Dog dog = new Dog();

		System.out.println("dog is:" + dog.name + "  " + dog.breed + " " + dog.legs + " " + dog.color);
		
		Dog dog2 = new Dog();

		System.out.println("dog is:" + dog2.name + "  " + dog2.breed + " " + dog2.legs + " " + dog2.color);
			

	}
}
