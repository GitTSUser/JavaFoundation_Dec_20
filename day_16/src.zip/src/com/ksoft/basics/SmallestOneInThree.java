//program to demo using if_else-if_ladder statement
package com.ksoft.basics;

import java.util.Scanner;

public class SmallestOneInThree {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		System.out.println("enter 3 numbers:");
		int a = scanner.nextInt();
		int b = scanner.nextInt();
		int c = scanner.nextInt();

		if (a < b && a < c) {
			System.out.println("a is smallest");
		} else if (b < a && b < c) {
			System.out.println("b is smallest");
		} else {
			System.out.println("c is smallest");
		}

		scanner.close();

	}
}
