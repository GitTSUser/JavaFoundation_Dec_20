//program to demo creation of stream on array
package com.ksoft.streams;

import java.util.Arrays;
import java.util.stream.IntStream;

public class StreamOperationDemo1 {

	public static void main(String[] args) {

		int arr[] = { 1, 2, 3, 4, 5, 6, 7, 9, 10 };

		IntStream intStream = Arrays.stream(arr); // getting IntStream
		IntStream evenIntStream = intStream.filter(ele -> ele % 2 == 0); // filtering even numbers
		evenIntStream.forEach(ele -> System.out.println("even is:" + ele)); // consume ele to print

		System.out.println("-----odd numbers----");
		IntStream intStream2 = Arrays.stream(arr);
		IntStream oddIntStream = intStream2.filter(ele -> ele % 2 != 0);
		oddIntStream.forEach(ele -> System.out.println("odd is:" + ele));

		System.out.println("---even numbers----");
		Arrays.stream(arr).filter(ele -> ele % 2 == 0).forEach(e -> System.out.println("even is:" + e));

	}
}
