//program to demo multiple inheritance with interfaces
package com.ksoft.inheritance;

interface Janwar {
	void eat();

	void sleep();
}

interface JanwarTwo {
	void move();
}

class Spiky {
}

class Dogg extends Spiky implements Janwar, JanwarTwo {

	public void eat() {
		System.out.println("dog eats biscuits");
	}

	public void sleep() {
		System.out.println("dog sleeps in den");
	}

	@Override
	public void move() {
		System.out.println("dog moves on legs");
	}

}

class Fish implements Janwar, JanwarTwo {

	@Override
	public void eat() {
		System.out.println("fish eats sea-food");
	}

	@Override
	public void sleep() {
		System.out.println("fish sleeps in water");
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("fish swims in water");
	}

}

public class MultipleInheritanceWithInterfaces {

	public static void main(String[] args) {

		// Janwar janwar = new Janwar();

		Fish fish = new Fish();

		fish.eat();
		fish.sleep();
		fish.move();

	}
}