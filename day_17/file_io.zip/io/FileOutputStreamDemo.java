//program to demo writing data to file using FileOutputStream
package com.ksoft.io;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamDemo {

	public static void main(String[] args) throws IOException {

		FileOutputStream fos = new FileOutputStream("F:\\Success.csv");

		String content = "See Your Goal," 
					+ "Understand the Obstacles," 
					+ " Create a Positive Mental Picture,"
					+ " Clear your mind of doubt," 
					+ " Embrace the Challenge," 
					+ " Stay on Track,"
					+ " Show the world what you did it!";

		fos.write(content.getBytes());

		System.out.println("content written to file");

		fos.close();
	}
}