//program to demonstrate use of switch-case
package com.ksoft.basics;

import java.util.Scanner;

public class HotelAshoka {

	public static void main(String[] args) {

		int noOfItems;
		double billAmount = 0.0;
		int dishCode;
		Scanner scanner = new Scanner(System.in);

		System.out.println("----Welcome to Hotel Ashoka----");

		System.out.println("1.Idly (2.00) \n 2.Dosa (2.50)");
		System.out.println("3.Puri (2.75) \n 4.Wada (3.00)");
		System.out.println("5.Upma (2.25)");
		System.out.println("enter dish code:");
		dishCode = scanner.nextInt();
		System.out.println("enter no.of plates:");
		noOfItems = scanner.nextInt();

		switch (dishCode) {
		case 1:
			billAmount = 2.00 * noOfItems;
			break;
		case 2:
			billAmount = 2.50 * noOfItems;
			break;

		case 3:
			billAmount = 2.75 * noOfItems;
			break;

		case 4:
			billAmount = 3.00 * noOfItems;
			break;
		case 5:
			billAmount = 2.25 * noOfItems;
			break;

		default:
			System.out.println("Invalid dish code entered!");
		}

		System.out.println("Pls pay bill amount:" + billAmount);
		System.out.println("---Thank you Visit Again---");
		scanner.close();
	}
}