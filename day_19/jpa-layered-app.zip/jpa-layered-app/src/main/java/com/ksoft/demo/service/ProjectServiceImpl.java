package com.ksoft.demo.service;

import java.util.List;

import com.ksoft.demo.dao.IProjectDao;
import com.ksoft.demo.dao.ProjectDaoImpl;
import com.ksoft.demo.entity.Project;

public class ProjectServiceImpl implements IProjectService {

	private static IProjectDao projectDao = new ProjectDaoImpl();

	public Project add(Project project) {
		return projectDao.addProject(project);
	}

	public Project update(Project project) {
		return projectDao.updateProject(project);
	}

	public boolean delete(int projectId) {
		return projectDao.deleteProject(projectId);
	}

	public Project getProject(int projectId) {
		return projectDao.getProject(projectId);
	}

	public List<Project> getAllProjects() {
		return projectDao.getAllProjects();
	}

}
