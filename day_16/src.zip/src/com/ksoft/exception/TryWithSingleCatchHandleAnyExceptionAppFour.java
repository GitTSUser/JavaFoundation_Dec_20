//program to demonstrate handling diff types of exceptions using single catch
package com.ksoft.exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TryWithSingleCatchHandleAnyExceptionAppFour {

	public static void main(String[] args) {

		Scanner scanner = null;
		try {
			scanner = new Scanner(System.in);
			System.out.println("enter a number:");
			int x = scanner.nextInt();
			System.out.println("enter another:");
			int y = scanner.nextInt();
			int z = x / y;
			System.out.println("division is:" + z);
		} catch (Exception ae) {

			if (ae instanceof ArithmeticException) {
				System.out.println("handling airthemtic Exception:" + ae.getMessage());
			}
			if (ae instanceof InputMismatchException) {
				System.out.println("handling input mis-match exception is:" + ae.getMessage());
			}
		}

		System.out.println("program ends");
		scanner.close();
	}
}