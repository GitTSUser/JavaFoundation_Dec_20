package com.ford.demo.service;

import com.ford.demo.model.Product;

import java.util.List;

public interface IProductService {

    public Product addProduct(Product product);
    public Product getProduct(int id);
    public List<Product> getAllProducts();
    public Product updateProduct(Product product);
    public String deleteProduct(int id);
}
