//program to demo the function takes nothing and returns nothing
package com.ksoft.methods;

public class MethodAppOne {

	// created a method :: function takes nothing and returns nothing
	static void printName() {
		System.out.println("Neha - Meghana");
	}

	// created a method :: function takes something and returns nothing
	static void printCity(String city) {
		System.out.println("city is:" + city);
	}

	static void findBooksAreSameOrNot(String book1, String book2) {

		if (book1.equals(book2)) {
			System.out.println("books are same");
		} else {
			System.out.println("books are not same");
		}
	}

	// created method:: function takes something and returns something
	static int add(int x, int y) {
		int z = x + y;
		return z;
	}

	public static void main(String[] args) {

//		printName();
//		printName();
//		printName();

//		printCity("Hyderabad");
//		printCity("Vishakapatnam");

//		findBooksAreSameOrNot("Java-CompleteReference", "Java-CompleteReference");

		int result = add(100, 200);
		System.out.println("sum of 100,200 is:" + result);
	}
}
