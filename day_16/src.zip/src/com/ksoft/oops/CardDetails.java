package com.ksoft.oops;

import java.time.LocalDate;

class Card {

	private long cardNo;
	private String cardType;
	private double creditLimit;
	private LocalDate dateOfExpiry;
	private int creditScore;

	// initializes card object
	public Card(long cardNo, String cardType, double creditLimit, LocalDate dateOfExpiry, int creditScore) {
		this.cardNo = cardNo;
		this.cardType = cardType;
		this.creditLimit = creditLimit;
		this.dateOfExpiry = dateOfExpiry;
		this.creditScore = creditScore;
	}

	public long getCardNo() {
		return this.cardNo;
	}

	public String getCardType() {
		return this.cardType;
	}

	public void setCreditLimit(double creditLimit) {
		this.creditLimit = creditLimit;
	}

	public double getCreditLimit() {
		return this.creditLimit;
	}

	public LocalDate getDateOfExpiry() {
		return dateOfExpiry;
	}

	public void setDateOfExpiry(LocalDate dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}

	public int getCreditScore() {
		return creditScore;
	}

	public void setCreditScore(int creditScore) {
		this.creditScore = creditScore;
	}

	public void setCardNo(long cardNo) {
		this.cardNo = cardNo;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

}

public class CardDetails {

	static void findCardsExpiredOrNot(Card[] cardArr) {

		for (int i = 0; i < cardArr.length; i++) {

			Card cc = cardArr[i];

			if (cc.getDateOfExpiry().isBefore(LocalDate.now())) {
				System.out.println(cc.getCardNo() + " ::Expired:: " + cc.getDateOfExpiry());
			} else {
				System.out.println(cc.getCardNo() + " ::Not Expired:: " + cc.getDateOfExpiry());
			}

		}

	}

	static void countCardsOfSameType(Card[] cardArr) {

		int debitCount = 0;
		int creditCount = 0;

		for (int i = 0; i < cardArr.length; i++) {

			Card cc = cardArr[i];

			String cardType = cc.getCardType();

			if (cardType.equals("Credit")) {
				creditCount++;
			} else {
				debitCount++;
			}
		}
		System.out.println("count of credit cards:" + creditCount);
		System.out.println("count of debit cards:" + debitCount);
	}

	private static void increaseCreditLimit(Card[] cardArr, long cardNo, double amount) {

		// if creditScore is between 700 to 850 then only increase creditLimit
		for (int i = 0; i < cardArr.length; i++) {
			Card currentCard = cardArr[i];
			long currentCardNo = currentCard.getCardNo();
			
			if (currentCardNo == cardNo) {
				int creditScore = currentCard.getCreditScore();
				if (creditScore > 700 && creditScore <= 850) {
					double currentLimit = currentCard.getCreditLimit();
					currentLimit = currentLimit + amount;
					currentCard.setCreditLimit(currentLimit);
					System.out.println("credit limit is updated");
					return;
				}
			}
		}
		System.out.println("card no does not exists or creditscore is not sufficient!");
	}

	public static void main(String[] args) {
		Card card1 = new Card(123456789, "Credit", 124000, LocalDate.now().plusYears(2), 650);
		Card card2 = new Card(23456789, "Debit", 124000, LocalDate.now().plusYears(4), 850);
		Card card3 = new Card(33456789, "Credit", 224000, LocalDate.now().plusYears(2), 650);
		Card card4 = new Card(423456789, "Credit", 75000, LocalDate.now().plusYears(1).minusYears(2), 843);
		Card card5 = new Card(523456789, "Debit", 124000, LocalDate.now().plusYears(5), 650);
		Card card6 = new Card(623456789, "Credit", 85000, LocalDate.now().plusYears(2), 450);

		Card cardArr[] = { card1, card2, card3, card4, card5, card6 };

		// findout cards expired or not
		findCardsExpiredOrNot(cardArr);

		// count the cards of same type
		countCardsOfSameType(cardArr);

		// increase creditLimit if creditScore is good on request
		increaseCreditLimit(cardArr, 23456789, 65000);
		
		System.out.println("currentLimit is:"+cardArr[1].getCreditLimit());
		
	}
}