package com.ksoft.inheritance;

import java.time.LocalDate;

class Card {

	long cardNum;
	String cardType;
	String cardName;
	LocalDate cardExpiryDate;

	public Card(long cardNum, String cardType, String cardName, LocalDate cardExpiryDate) {
		this.cardNum = cardNum;
		this.cardType = cardType;
		this.cardName = cardName;
		this.cardExpiryDate = cardExpiryDate;
	}

	public String cardInfo() {
		return cardNum + " " + cardType + " " + cardName + " " + cardExpiryDate;
	}
}

class CreditCard extends Card {

	double creditLimit;
	int rewardPoints;
	String cardHolder;
	double purchases[];
	int billingDays;

	public CreditCard(long cardNum, String cardType, String cardName, LocalDate cardExpiryDate, double creditLimit,
			String cardHolder, int billingDays) {
		super(cardNum, cardType, cardName, cardExpiryDate); // call to parent class constructor
		this.creditLimit = creditLimit;
		this.cardHolder = cardHolder;
		this.billingDays = billingDays;

	}

	public String creditCardInfo() {
		return super.cardInfo() + " " + this.creditLimit + " " + this.cardHolder + " " + this.billingDays;
	}

}

public class CreditCardPurchasesDemo {

	public static void main(String[] args) {

		Card card = new Card(456456789, "Maestro", "Rupay", LocalDate.of(2026, 7, 15));

		System.out.println(card.cardInfo());

		CreditCard cc = new CreditCard(56456456, "VISA", "Platino", LocalDate.of(2027, 8, 23), 85000.25, "ArunKumar",
				30);

		System.out.println(cc.creditCardInfo());
	}
}