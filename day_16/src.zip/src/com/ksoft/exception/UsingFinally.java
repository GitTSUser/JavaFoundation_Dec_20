//program to demo using "finally" in 3 situations: a) in case of exception b) in case of no-exception c) incase of return statement

package com.ksoft.exception;

public class UsingFinally {

	// in-case of exception, how finally works
	private static void method1() {

		System.out.println("method-1 execution started");
		try {
			throw new ArithmeticException("exception raised");
		} catch (ArithmeticException ae) {
			System.out.println("exception is :" + ae.getMessage());
		} finally {
			System.out.println("finall block-method1 executes");
		}
		System.out.println("method-1 execution ends");
	}

	// in-case of no-exception , how finally works
	private static void method2() {
		System.out.println("method-2 execution started");
		try {
			// no exception
		} catch (ArithmeticException ae) {
			System.out.println("exception is :" + ae.getMessage());
		} finally {
			System.out.println("finall block-method2 executes");
		}
		System.out.println("method-2 execution ends");
	}

	// in-case of return statement how finally works
	private static void method3() {
		System.out.println("method-3 execution started");
		try {
			return;
		} catch (ArithmeticException ae) {
			System.out.println("exception is :" + ae.getMessage());
		} finally {
			System.out.println("finall block-method3 executes");
		}
		System.out.println("method-3 execution ends");
	}

	public static void main(String[] args) {
		//method1();
		// method2();
		 method3();
	}
}
