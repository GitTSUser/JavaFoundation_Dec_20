package com.ksoft.app.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ksoft.app.model.Course;

@Service
public class CourseServiceImpl implements ICourseService {

	private static List<Course> courseList;

	static {

		Course c1 = new Course(1, "Java FSD", 45000.25, 6);
		Course c2 = new Course(2, "AI/ML", 35000.25, 3);
		Course c3 = new Course(3, "UI/UX", 25000.25, 2);

		courseList = Arrays.asList(c1, c2, c3);
	}

	@Override
	public List<Course> getAllCourses() {
		return courseList;
	}

	@Override
	public Course getSingleCourse(int courseId) {
		return courseList.stream().filter(c -> c.getId() == courseId).findAny().get();
	}

	@Override
	public Course addNewCourse(Course course) {
		courseList.add(course);
		return course;
	}

	@Override
	public Course updateCourse(Course course) {
		Optional<Course> courseToUpdate = courseList.stream().filter(c -> c.getId() == course.getId()).findAny();
		courseToUpdate.ifPresent(c -> {
			c.setName(course.getName());
			c.setPrice(course.getPrice());
			c.setDuration(course.getDuration());
		});

		return courseToUpdate.get();
	}

	@Override
	public boolean deleteCourse(int courseId) {
		Optional<Course> courseToRemove = courseList
				.stream()
				.filter(c -> c.getId() == courseId)
				.findAny();
		
		if (courseToRemove.isPresent()) {
			courseList.remove(courseToRemove.get());
			return true;
		}

		return false;
	}

}
