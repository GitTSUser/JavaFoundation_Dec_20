//program to demo printing the numbers using IntStream
package com.ksoft.streams;

import java.util.stream.IntStream;

public class StreamOperationDemo3 {

	public static void main(String[] args) {

		IntStream numStream = IntStream.rangeClosed(90, 100);

		numStream.forEach(ele -> System.out.println("ele is:" + ele));

		System.out.println("sum of 11 to 20 nums is:" + IntStream.rangeClosed(1, 5).sum());

	}
}
