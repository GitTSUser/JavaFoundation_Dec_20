//program to demonstrate creation of object
package com.ksoft.oops;

class Dog {
	// properties
	int tag;
	String name;
	String breed;
	int legs;
	String color;
}

public class AppOne {

	public static void main(String[] args) {

		Dog d1 = new Dog(); // object creation

		// object initialization
		d1.tag = 12345;
		d1.name = "Ruby";
		d1.breed = "Labrador";
		d1.legs = 4;
		d1.color = "gold";

		System.out.println(d1.tag + " " + d1.name + " " + d1.breed);
		System.out.println(d1.legs + " " + d1.color);

		System.out.println("--------------------------------------");
		Dog d2 = new Dog();
		d2.tag = 123456;
		d2.name = "Chimtu";
		d2.breed = "Retriever";
		d2.legs = 3;
		d2.color = "brown";
		
		System.out.println(d2.tag + " " + d2.name + " " + d2.breed);
		System.out.println(d2.legs + " " + d2.color);
	}
}