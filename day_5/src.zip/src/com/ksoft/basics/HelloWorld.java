package com.ksoft.basics;

public class HelloWorld {

	public static void main(String[] args) {

		System.out.println("welcome to HelloWorld");
		System.out.print("Welcome to Java Programming");

	}
}
