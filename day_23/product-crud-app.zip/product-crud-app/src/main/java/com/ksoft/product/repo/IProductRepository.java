package com.ksoft.product.repo;

import java.util.List;

import com.ksoft.product.model.Product;

public interface IProductRepository {

	public Product addProduct(Product product);

	public Product getProduct(int productId);

	public Product updateProduct(Product product);

	public List<Product> getAllProducts();

	public boolean deleteProduct(int productId);

}
