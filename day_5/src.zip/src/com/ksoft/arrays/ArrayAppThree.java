//program to find out the pass count and fail count of 5 students
package com.ksoft.arrays;

import java.util.Scanner;

public class ArrayAppThree {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		int marks[][] = new int[5][6];
		int mark;
		int passCount = 0;
		int failCount = 0;

		boolean passOrFailFlag = true; // assume student passed initially

		for (int i = 0; i < marks.length; i++) {

			System.out.println("enter student-" + (i + 1) + " marks(6-sub):");

			for (int j = 0; j < marks[i].length; j++) {
				mark = scanner.nextInt();

				if (mark < 40) {
					passOrFailFlag = false;
				}
				marks[i][j] = mark;
			}

			if (passOrFailFlag == false) {
				failCount++;
			} else {
				passCount++;
			}

			passOrFailFlag = true; // assume again student passed
		}
		System.out.println("passcount is:" + passCount);
		System.out.println("failcount is:" + failCount);
		scanner.close();
	}
}