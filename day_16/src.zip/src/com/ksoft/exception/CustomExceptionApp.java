//program to demonstrate creation of custom exception
package com.ksoft.exception;

import com.ksoft.exception.ABCBank.BankAccount;
class InvalidAgeException extends RuntimeException {

	private String exceptionMsg;

	public InvalidAgeException(String exceptionMsg) {
		System.out.println("step-1");
		System.out.println("step-2");
		this.exceptionMsg = exceptionMsg;
	}

	public String toString() {
		return this.exceptionMsg;
	}

}

class ABCBank {

	static class BankAccount {
		private long acntNo;
		private String acntHolder;
		private double acntBalance;
		private int acntHolderAge;

		private BankAccount(long acntNo, String acntHolder, double acntBalance, int acntHolderAge) {
			this.acntNo = acntNo;
			this.acntHolder = acntHolder;
			this.acntBalance = acntBalance;
			this.acntHolderAge = acntHolderAge;
		}

		public String acntInfo() {
			return this.acntNo + " " + this.acntHolder + " " + this.acntBalance + " " + this.acntHolderAge;
		}

	}

	public static BankAccount createAccount(String name, int age, double balance) {
		try {
			if (age < 18) {
				throw new InvalidAgeException("age is not sufficient to open account!");
			}
			long acntNo = (long) Math.random() + 123456;
			BankAccount bankAccount = new BankAccount(acntNo, name, balance, age);
			return bankAccount;
		} catch (InvalidAgeException iae) {
			System.out.println("Exception is:" + iae);
		}
		return null;
	}
}

public class CustomExceptionApp {

	public static void main(String[] args) {

		BankAccount ba = ABCBank.createAccount("hitha", 26, 2500.25);
		if (ba != null) {
			System.out.println(ba.acntInfo());
		}
	}
}