//program to demonstrate implementation of Hide and Seek using arrays
package com.ksoft.arrays;

import java.util.Scanner;

public class HideAndSeek {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		int boxes[] = null;

		boolean flag = true;
		int choice = 0;
		int n = 0;
		while (flag) {
			System.out.println("----Hide/Seek Game----");
			System.out.println("1. Hide \n 2.Seek \n 3.Club \n 4.Open-up \n 5.Exit");
			System.out.println("enter your choice:");
			choice = Integer.parseInt(scanner.next());

			switch (choice) {
			case 1:
				System.out.println("how many you want to hide:");
				n =Integer.parseInt(scanner.next());
				boxes = new int[n];
				for (int i = 0; i < n; i++) {
					boxes[i] = (int) Math.abs(Math.random() * 4562 * 12);
				}
				System.out.println("all kids hidden");
				break;
			case 4:
				for (int i = 0; i < boxes.length; i++) {
					System.out.print(" " + boxes[i]);
				}
				break;
			case 5:
				System.out.println("closing app");
				flag = false;
			}

		}
		scanner.close();

	}
}
