package com.ford.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityJwtBasedApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurityJwtBasedApplication.class, args);
    }

}
