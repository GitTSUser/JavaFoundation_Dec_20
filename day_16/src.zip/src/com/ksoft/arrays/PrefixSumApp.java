//program to find the prefix sum array
package com.ksoft.arrays;

import java.util.Arrays;

public class PrefixSumApp {

	private static void prefixSumArray(int[] a) {

		for (int i = 1; i < a.length; i++) {
			a[i] = a[i - 1] + a[i];
		}

	}

	public static void main(String[] args) {

		int arr[] = { 1, 2, 3, 4, 5, 6, 7 };

		System.out.println("array is:" + Arrays.toString((arr)));

		prefixSumArray(arr);

		System.out.println("prefix-sum array is:" + Arrays.toString((arr)));
	}

}
