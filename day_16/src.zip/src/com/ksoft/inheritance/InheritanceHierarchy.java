package com.ksoft.inheritance;

class K{

	public K() {
		System.out.println("K- constructor");
	}
}

class X extends K {
	public X() {
		System.out.println("X- constructor");
	}
}

class Y extends X {
	public Y() {
		System.out.println("Y- constructor");
	}
}

public class InheritanceHierarchy {

	public static void main(String[] args) {
		X obj = new X();
	}
}
