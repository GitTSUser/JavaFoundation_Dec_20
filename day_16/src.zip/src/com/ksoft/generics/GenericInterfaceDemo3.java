//program to demo generic interface creation and implementation
package com.ksoft.generics;

interface Operable<T, U> {

	public abstract void performAddition(T t, U u);
}

class DoubleOperation implements Operable<Double, Double> {

	@Override
	public void performAddition(Double t, Double u) {
		System.out.println("d-sum is:" + (t + u));
	}
}

class IntOperation implements Operable<Integer, Integer> {

	@Override
	public void performAddition(Integer t, Integer u) {
		System.out.println("sum is:" + (t + u));
	}

	/*
	 * @Override public void performAddition(Object t, Object u) { Integer i1 =
	 * null; Integer i2 = null; if (t instanceof Integer && u instanceof Integer) {
	 * i1 = (Integer) t; i2 = (Integer) u; System.out.println("sum is:" + (i1 +
	 * i2)); }
	 * 
	 * if (t instanceof Double && u instanceof Double) { Double d1 = (Double) t;
	 * Double d2 = (Double) u; System.out.println("d-sum is:" + (d1 + d2)); }
	 * 
	 * }
	 */
}

public class GenericInterfaceDemo3 {

	public static void main(String[] args) {

		IntOperation op1 = new IntOperation();
		op1.performAddition(120, 250);

		DoubleOperation dp1 = new DoubleOperation();

		dp1.performAddition(12.25, 13.25);
	}
}