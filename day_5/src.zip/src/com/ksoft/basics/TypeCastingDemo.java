//program to demonstrate type conversion
/*
 * There are 2 types of conversion: implicit  and explicit
 * 
 * implicit:- done by the language or system
 *             if 2 conditions are met
 *             a) both types should be of same category
 *             b)  target type memory > source type memory
 * 
 *        eg:-   short  s=200;
 *               int i;
 *               
 *               i = s;  //works 
 *               
 *          ii) long  k=7895;
 *          
 *          	int i;
 *          
 *              i=k; // will not work
 *              
 *              
 *              
 *             
 * explicit:- done by the programmer using cast operator
 * 
 * 			eg:-  long k=7895;
 * 				   int i;
 * 
 *                i= (int)k; //will work
 *                
 *         ii)   double d=45.25;
 *         		
 *         		 short s;
 *         
 *               s= (short) d;  //will work
 *                
 * 
 */
package com.ksoft.basics;

public class TypeCastingDemo {

	public static void main(String[] args) {

		double d = 45.25;

		short s;

		s = (short) d;

		System.out.println("short value is:" + s);

		long l = 457;

		byte b = (byte) l;

		System.out.println("byte value is:" + b);

		char c = 'A';
		int i = 35;

		System.out.println("sum is:" + (c + i));
	}
}