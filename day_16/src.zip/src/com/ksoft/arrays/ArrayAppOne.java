//program to demonstrate  array initialization
package com.ksoft.arrays;

public class ArrayAppOne {

	public static void main(String[] args) {

		String cities[] = { "Hyderbad", "Secunderabad", "Ahemdabad", "Adhilabad", "Nizamabad" };

		for (int i = 0; i < cities.length; i++) {
			System.out.println("city is:" + cities[i]);
		}

	}
}