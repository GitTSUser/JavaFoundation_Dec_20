//program to demo if-else statement
package com.ksoft.basics;

import java.util.Scanner;

public class EligibleToVote {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter your age:");

		int age = scanner.nextInt();

		if (age >= 18) {
			System.out.println("eligible to vote");
		} else {
			System.out.println("not eligible to vote");
		}
		scanner.close();
	}
}