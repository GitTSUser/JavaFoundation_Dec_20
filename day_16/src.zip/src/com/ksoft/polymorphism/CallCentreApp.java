package com.ksoft.polymorphism;

class CallCenter {
	public static void handlecall(StandardCustomer sc, String issue) {
		System.out.println("Handling call with Customer:" + sc.getName());
		System.out.println("Fixing the issue in 5 min: " + issue);
	}
	public static void handlecall(PremiumCustomer sc, String issue) {
		System.out.println("Handling call with Customer:" + sc.getName());
		System.out.println("Fixing the issue in 10 min: " + issue);
	}
	public static void handlecall(PlatinumCustomer sc, String issue) {
		System.out.println("Handling call with Customer:" + sc.getName());
		System.out.println("Fixing the issue in 15 min: " + issue);
	}
}
class StandardCustomer {
	private int id;
	private String name;
	private String city;

	public StandardCustomer(int id, String name, String city) {
		this.id = id;
		this.name = name;
		this.city = city;

	}

	public int getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

}

class PremiumCustomer {
	private int id;
	private String name;
	private String city;
	private String email;

	public PremiumCustomer(int id, String name, String city, String email) {
		this.id = id;
		this.name = name;
		this.city = city;
		this.email = email;
	}

	public int getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public String getEmail() {
		return this.email;
	}
}

class PlatinumCustomer {
	private int id;
	private String name;
	private String city;
	private String email;
	private long phone;

	public PlatinumCustomer(int id, String name, String city, String email, long phone) {
		this.id = id;
		this.name = name;
		this.city = city;
		this.email = email;
		this.phone = phone;

	}

	public int getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public String getEmail() {
		return this.email;
	}

	public long getPhone() {
		return this.phone;
	}
}
public class CallCentreApp {

	public static void main(String[] args) {
		PremiumCustomer pc = new PremiumCustomer(1001, "Keerthana", "Hyderabad", "abc@yahoo.com");
		String issue = "Not able to use my creditcard";
		CallCenter.handlecall(pc, issue);
		PlatinumCustomer ppc = new PlatinumCustomer(1002, "SanKeerthana", "Ooty", "xyz@yahoo.com", 123456788);
		String issue2 = "Not able to use my debitcard";
		CallCenter.handlecall(ppc, issue2);
	}
}