//program to demo method overriding

package com.ksoft.polymorphism;

class SBI {
	protected static int roi = 12;

	public static double calculateInterest(double amount, int noOfYears) {
		System.out.println("SBI providing roi is:" + roi);
		return amount + (amount * noOfYears * roi / 100);
	}
}

class SBH extends SBI {
	protected static int roi = SBI.roi + 2;

	public static double calculateInterest(double amount, int noOfYears) {
		System.out.println("SBH providing roi is:" + roi);
		return amount + (amount * noOfYears * roi / 100);
	}
}

class SBK extends SBH {

	private static int roi;

	{
		roi = SBH.roi + 3;
	}

	public static double calculateInterest(double amount, int noOfYears) {

		System.out.println("SBK providing roi is:" + roi);
		return amount + (amount * noOfYears * roi / 100);
	}
}

public class MethodOverridingDemo {

	public static void main(String[] args) {

		System.out.println("sbi amount is:" + SBI.calculateInterest(25000, 3));
		System.out.println("sbh amount is:" + SBH.calculateInterest(25000, 3));
		System.out.println("sbh amount is:" + SBK.calculateInterest(25000, 3));
	}
}