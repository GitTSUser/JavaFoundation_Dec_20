//program to demonstrate  method overloading
package com.ksoft.polymorphism;

class Calculator {
	public static int add(int a, int b) {
		return a + b;
	}

	public static double add(double a, double b) {
		return a + b;
	}

	public static String add(String m, String n) {
		return m + n;
	}

	public static int add(int a, int b, int c) {
		return a + b + c;
	}
}

public class MethodOverloadingDemo {

	public static void main(String[] args) {
		// Calculator calc = new Calculator();
		System.out.println("addition is:" + Calculator.add(120.23, 100));
		System.out.println("addition of two strings:" + Calculator.add("abc", "xyz"));
	}
}