package com.ksoft.app.service;

import java.util.List;

import com.ksoft.app.model.Course;

public interface ICourseService {

	public List<Course> getAllCourses();

	public Course getSingleCourse(int courseId);

	public Course addNewCourse(Course course);

	public Course updateCourse(Course course);
	public boolean deleteCourse(int courseId);
}
