//program to print the good cities
package com.ksoft.methods;

public class MethodAppThree {

	static void findGoodCities(String cities[], String badString) {

		System.out.println("Good Cities:");
		for (int i = 0; i < cities.length; i++) {
			if (!cities[i].contains(badString)) {
				System.out.println("city is:" + cities[i]);
			}
		}

	}

	public static void main(String[] args) {

		String cities[] = { "Hyderabad", "Secunderabad", "Kurnool", "Warangal", "Goa", "Ahmedhabad", "Adilabad" };

		String badString = "bad";
		findGoodCities(cities, badString);
	}
}
