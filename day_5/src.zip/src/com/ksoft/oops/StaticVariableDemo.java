//program to demo static variables creation
package com.ksoft.oops;

class Employee {

	private static String company; //static variable

	//non-static variables
	private int id;
	private String name;
	private double salary;

	static {
		company = "CG"; //initializes static variables
	}
	
	{
		   //intialized non-static variables
	}

	public Employee(int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public String employInfo() {
		return this.id + " " + this.name + " " + this.salary + "  " + company;
	}

}

public class StaticVariableDemo {

	public static void main(String[] args) {

		Employee emp = new Employee(1001, "roja", 45000.25);
//		emp.company = "CGgg";
		System.out.println(emp.employInfo());

		Employee emp2 = new Employee(1002, "puja", 55000.25);
		System.out.println(emp2.employInfo());

		Employee emp3 = new Employee(1003, "Srija", 65000.25);
		System.out.println(emp3.employInfo());

	}

}
