package com.ksoft.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ksoft.product.model.Product;
import com.ksoft.product.repo.IProductRepository;

import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Service

public class ProductServiceImpl implements IProductService {

	@Autowired
	@Qualifier("productRepositoryImplTwo")
	private IProductRepository productRepository;

	@Override
	public Product saveProduct(Product product) {
		return productRepository.addProduct(product);
	}

	@Override
	public Product updateProduct(Product product) {
		return productRepository.updateProduct(product);
	}

	@Override
	public Product findProduct(int productId) {
		return productRepository.getProduct(productId);
	}

	@Override
	public List<Product> findAllProducts() {
		return productRepository.getAllProducts();
	}

	@Override
	public boolean removeProduct(int productId) {
		return productRepository.deleteProduct(productId);
	}
}