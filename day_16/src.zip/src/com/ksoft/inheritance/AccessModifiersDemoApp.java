//program to demo the access modifiers  
package com.ksoft.inheritance;

class HelloWorld {
	private int x = 100;
	protected double y = 200.23;
	String z = "abc"; // this variable has default access
	public char grade = 'A';
}

public class AccessModifiersDemoApp {

	public static void main(String[] args) {

		HelloWorld helloWorld = new HelloWorld();

		// System.out.println("x is:" + helloWorld.x);
		System.out.println("y is:" + helloWorld.y);
		System.out.println("z is:" + helloWorld.z);
		System.out.println("grade is:" + helloWorld.grade);
		// except private members are others are visible
	}
}