//program to give intro to dynamic method dispatch
package com.ksoft.polymorphism;

interface Animal {

	void eat();

	void sleep();

	void move();

	String getName();
}

class Dog implements Animal {

	private String name;

	public Dog(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	@Override
	public void eat() {
		System.out.println("dog eats biscuits");
	}

	@Override
	public void sleep() {
		System.out.println("dog sleeps in den");
	}

	@Override
	public void move() {
		System.out.println("dog moves on legs");
	}

}

class Bird implements Animal {

	private String name;

	public Bird(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	@Override
	public void eat() {
		System.out.println("bird eats nuts");
	}

	@Override
	public void sleep() {
		System.out.println("bird sleeps in nest");
	}

	@Override
	public void move() {
		System.out.println("bird flies on wings");
	}

	public void sing() {
		System.out.println("bird sings songs");
	}
}

class Dolphin implements Animal {

	private String name;

	public Dolphin(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	@Override
	public void eat() {
		System.out.println("dolphin eats fish");
	}

	@Override
	public void sleep() {
		System.out.println("dolphin sleeps in water");
	}

	@Override
	public void move() {
		System.out.println("dolphin swims in water");
	}
}

class AnimalTrainer {

	public static void train(Animal animal) {
		System.out.println("trainer started training to::" + animal.getName());
		animal.eat();
		animal.move();
		animal.sleep();
		if (animal instanceof Bird) {
			Bird bird = (Bird) animal; // down casting
			bird.sing();
		}
		System.out.println("trainer completed training to::" + animal.getName());
	}

	/*
	 * public static void train(Dog dog) {
	 * System.out.println("trainer started training to::" + dog.getName());
	 * dog.eat(); dog.move(); dog.sleep();
	 * System.out.println("trainer completed training to::" + dog.getName()); }
	 * 
	 * public static void train(Bird bird) {
	 * System.out.println("trainer started training to::" + bird.getName());
	 * bird.eat(); bird.move(); bird.sleep();
	 * System.out.println("trainer completed training to::" + bird.getName());
	 * 
	 * }
	 */
}

public class DynamicMethodDispatchDemo {

	public static void main(String[] args) {
		Dog dog = new Dog("Puppy");
		Dolphin dolphin = new Dolphin("Dolly");
		Bird bird = new Bird("Buddy");

		AnimalTrainer.train(dog); // sending dog to trainer for training
		AnimalTrainer.train(bird);
		AnimalTrainer.train(dolphin);
	}
}