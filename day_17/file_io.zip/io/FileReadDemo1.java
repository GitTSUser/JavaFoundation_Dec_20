//program to demo  to know about a file
package com.ksoft.io;

import java.io.File;
import java.util.Arrays;
import java.util.List;

public class FileReadDemo1 {

	public static void main(String[] args) {

		File file = new File("F:\\demo.txt");

		System.out.println("file name is:" + file.getName());

		System.out.println("file does exists:" + file.exists());

		System.out.println("filepath is:" + file.getPath());

		System.out.println("file name is:" + file.getName());

		File file2 = new File("E:\\");

		String files[] = file2.list();

		for (String f : files) {

			System.out.println("file is:" + f);
		}

		System.out.println("----files/directories----");
		File[] filesArr = file2.listFiles();

		Arrays.stream(filesArr).forEach(myFile -> {

			if (myFile.isFile()) {
				System.out.println("file is:" + myFile.getAbsolutePath());
			} else {
				System.out.println("dir is:" + myFile.getAbsolutePath());
			}

		});

	}
}