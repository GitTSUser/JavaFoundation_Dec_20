package com.ksoft.functional;

@FunctionalInterface
interface VowelsFindable {

	public abstract int findVowels(String cityName);

}

public class FunctionalInterfaceDemo2 {

	public static void main(String[] args) {
		

	}
}
