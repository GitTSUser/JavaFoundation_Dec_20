//program to demo creation of Generic method
package com.ksoft.generics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class HelloWorld {

	public static <T extends Number> void printElements(T[] elements) {
		for (T t : elements) {
			System.out.println("element is:" + t);
		}
	}

	public static <T extends String> void copyElements(List<? extends T> source, List<? super T> destination) {
		for (T ele : source) {
			destination.add(ele);
		}
	}

}

public class GenericMethodDemo4 {

	public static void main(String[] args) {

		Integer numArr[] = { 100, 200, 300, 400, 500 };
		HelloWorld.printElements(numArr);
		System.out.println("------salaries-------");
		Double salaryArr[] = { 12000.25, 25000.35, 34000.28, 66500.28 };
		HelloWorld.printElements(salaryArr);

		System.out.println("------cities-----");
		String[] cities = { "Pearl-city", "Diamond City", "Pink City", "BlueStone City" };
		List<String> copiedCities = new ArrayList<>();
		HelloWorld.copyElements(Arrays.asList(cities), copiedCities);
		System.out.println("copiedCities are:" + copiedCities);

		/*
		 * List<Integer> numList = new ArrayList<>();
		 * HelloWorld.copyElements(Arrays.asList(numArr), numList);
		 */
	}
}