package com.ksoft.streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.Stream;

class Student {

	private int id;
	private String name;
	private String branch;
	private double fee;
	private int yos;

	public Student(int id, String name, String branch, double fee, int yos) {
		super();
		this.id = id;
		this.name = name;
		this.branch = branch;
		this.fee = fee;
		this.yos = yos;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public double getFee() {
		return fee;
	}

	public void setFee(double fee) {
		this.fee = fee;
	}

	public int getYos() {
		return yos;
	}

	public void setYos(int yos) {
		this.yos = yos;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", branch=" + branch + ", fee=" + fee + ", yos=" + yos + "]";
	}

}

public class StreamOperationsDemo5 {

	private static void loadStudents(List<Student> studentList) {
		Student s1 = new Student(1001, "arun", "CSE", 45000.25, 1);
		Student s2 = new Student(1003, "tarun", "EEE", 35000.25, 3);
		Student s3 = new Student(1002, "varun", "ECE", 37000.25, 2);
		Student s4 = new Student(1004, "sharun", "CSE", 95000.25, 3);
		Student s5 = new Student(1005, "charun", "IT", 45000.25, 3);
		Student s6 = new Student(1008, "karun", "ECE", 45000.25, 4);
		Student s7 = new Student(1007, "marun", "CSE", 65000.25, 1);
		Student s8 = new Student(1006, "narun", "IT", 75000.25, 3);

		studentList.addAll(Arrays.asList(s1, s2, s3, s4, s5, s6, s7, s8));

		System.out.println(studentList.size() + " students added");
	}

	private static List<Student> getStudentsByBranch(List<Student> studentList, String branch) {

		// List<Student> resultList = new ArrayList<>();

		/*
		 * for (int i = 0; i < studentList.size(); i++) { Student s =
		 * studentList.get(i); // getting one student object String studBranch =
		 * s.getBranch(); // getting branch from student object if
		 * (studBranch.equals(branch)) { // comparing that brach with given branch
		 * resultList.add(s); // adding student object to resultList } }
		 */

		return studentList.stream().filter((st) -> st.getBranch().equals(branch)).collect(Collectors.toList());

	}

	private static double findTotalFeeByBranch(List<Student> studentList, String keyBranch) {

		/*
		 * double total = 0.0;
		 * 
		 * for (int i = 0; i < studentList.size(); i++) {
		 * 
		 * Student s = studentList.get(i); // one student object from list String
		 * studBranch = s.getBranch();
		 * 
		 * if (studBranch.equals(branch)) { // verifying the student branch is IT or not
		 * total = total + s.getFee(); }
		 * 
		 * }
		 * 
		 * return total;
		 */

		/*
		 * Stream<Student> studentStream = studentList.stream(); // getting stream of
		 * students Stream<Student> keyBranchStream = studentStream.filter(st ->
		 * st.getBranch().equals(keyBranch));// getting DoubleStream feeStream =
		 * keyBranchStream.mapToDouble(st -> st.getFee()); // stream of student fee
		 * 
		 * double total = feeStream.sum(); // perform sum of fees
		 * 
		 * return total;
		 */

		return studentList
				.stream()
				.filter(st -> st.getBranch().equals(keyBranch))
				.mapToDouble(st -> st.getFee())
				.sum();
	}

	private static List<Student> getStudentsByBranchOrderByName(List<Student> studList, String keyBranch) {

		return studList
				.stream()
				.filter(st -> st.getBranch().equals(keyBranch))
				.sorted((s1, s2) -> s1.getName().compareTo(s2.getName()))
				.collect(Collectors.toList());

	}

	public static void main(String[] args) {

		List<Student> students = new ArrayList<>();
		loadStudents(students);

		List<Student> cseStudentList = getStudentsByBranch(students, "CSE");

		cseStudentList.forEach(s -> System.out.println(s));

		double totalFeeByIT = findTotalFeeByBranch(students, "IT");

		System.out.println("fee paid by IT students is:" + totalFeeByIT);

		List<Student> nameWiseOrderedList = getStudentsByBranchOrderByName(students, "CSE");

		System.out.println("----student of CSE by named order---");
		nameWiseOrderedList.forEach(st -> System.out.println(st));
	}
}
