//program to handle array index out of bound exception
package com.ksoft.exception;

public class ExceptionAppTwo {

	public static void main(String[] args) {

		String names[] = { "Charitha", "Harshitha", "Kavitha", "Varshitha" };

		try {
			for (int i = 0; i < names.length; i++) {

				System.out.println("name is:" + names[i]);
			}
		} catch (ArrayIndexOutOfBoundsException aioobe) {
			System.out.println("Exception is:" + aioobe.getMessage());
		}

		System.out.println("program ends");

	}
}