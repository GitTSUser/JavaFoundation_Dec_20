package com.ksoft.collections;

import java.util.Arrays;
import java.util.HashSet;

class Project {

	private int id;
	private String name;
	private String manager;
	private String domain;
	private double cost;
	private int teamSize;

	public Project(int id, String name, String manager, String domain, double cost, int teamSize) {
		super();
		this.id = id;
		this.name = name;
		this.manager = manager;
		this.domain = domain;
		this.cost = cost;
		this.teamSize = teamSize;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public int getTeamSize() {
		return teamSize;
	}

	public void setTeamSize(int teamSize) {
		this.teamSize = teamSize;
	}

	@Override
	public String toString() {
		return "Project [id=" + id + ", name=" + name + ", manager=" + manager + ", domain=" + domain + ", cost=" + cost
				+ ", teamSize=" + teamSize + "]";
	}

	@Override
	public int hashCode() {
		return this.id;
	}

	@Override
	public boolean equals(Object obj) {

		Project p1 = (Project) this;
		Project p2 = (Project) obj;

		if (p1.getId() == p2.getId()) {

			if (p1.getName().equals(p2.getName())) {

				if (p1.getManager().equals(p2.getManager())) {

					if (p1.getDomain().equals(p2.getDomain())) {

						if (p1.getCost() == p2.getCost()) {

							if (p1.hashCode() == p2.hashCode()) {
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	}
}

public class ProjectSetDemo {

	private static void loadProjects(HashSet<Project> projects) {
		Project p1 = new Project(1001, "CMS", "meghana", "Payment", 12000, 6);
		Project p2 = new Project(1002, "BCMS", "Alekya", "Healthcare", 33000, 4);
		Project p3 = new Project(1003, "Accudose", "Meenasri", "Healthcare", 22000, 4);
		Project p4 = new Project(1004, "Flowerist", "Harshita", "Healthcare", 42000, 4);
		Project p5 = new Project(1005, "AdSense", "Swathi", "Healthcare", 82000, 4);
		Project p6 = new Project(1006, "SmartHomes", "Sathvikka", "Healthcare", 14000, 4);
		Project p7 = new Project(1007, "DDOS", "Bindhu", "Healthcare", 55000, 4);
		Project p8 = new Project(1008, "SpamDet", "Manasa", "Healthcare", 62000, 4);
		Project p9 = new Project(1001, "CMS", "meghana", "Payment", 12000, 6);
		Project p10 = new Project(1001, "CMS", "meghana", "Payment", 12000, 6);
		projects.addAll(Arrays.asList(p1, p2, p3, p4, p5, p6, p7, p8, p9, p10));

		System.out.println("p1 hashCode is:" + p1.hashCode());
		System.out.println("p9 hashCode is:" + p9.hashCode());
		System.out.println("p10 hashCode is:" + p10.hashCode());

		System.out.println("p1 is equals to p9::" + p1.equals(p9));

		System.out.println(projects.size() + " projects added into HashSet");
	}

	public static void main(String[] args) {
		HashSet<Project> projectSet = new HashSet<Project>();
		loadProjects(projectSet);
	}
}