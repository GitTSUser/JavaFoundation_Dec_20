package com.ksoft.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FruitListDemo {

	private static void addFruit(ArrayList<String> fruitList, String fruit) {
		fruitList.add(fruit);
		System.out.println("fruit " + fruit + " added into list");
	}

	private static void addManyFruits(ArrayList<String> fruitList, List<String> fruits) {
		fruitList.addAll(fruits);
		System.out.println(fruits.size() + "-fruits are added to list");
	}

	private static void printAllFruits(ArrayList<String> fruitList) {
		System.out.println("----Fruit List is----");
		for (String fruit : fruitList) {
			System.out.println("fruit is:" + fruit);
		}
	}

	public static void main(String[] args) {

		ArrayList<String> fruitList = new ArrayList<String>();
		addFruit(fruitList, "Mango");

		List<String> fruits = Arrays.asList("Orange", "Banana", "Apple", "Watermelon", "Grapes", "Mango", "Papaya");
		addManyFruits(fruitList, fruits);
		printAllFruits(fruitList);
	}
}