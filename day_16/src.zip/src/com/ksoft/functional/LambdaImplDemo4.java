//program to find out the location wise employees
package com.ksoft.functional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@FunctionalInterface
interface LocationWise {
	public abstract List<Employ> findLocationWise(List<Employ> empList, String loc);
}

class Employ {
	private int id;
	private String name;
	private double salary;
	private String role;
	private String location;

	public Employ(int id, String name, double salary, String role, String location) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.role = role;
		this.location = location;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Employ [id=" + id + ", name=" + name + ", salary=" + salary + ", role=" + role + ", location="
				+ location + "]";
	}

}

public class LambdaImplDemo4 {

	public static void main(String[] args) {

		LocationWise lw = (empList, loc) -> {
			List<Employ> resultList = new ArrayList<>();
			for (Employ emp : empList) {
				String location = emp.getLocation();

				if (location.equalsIgnoreCase(loc)) {
					resultList.add(emp);
				}
			}
			return resultList;
		};

		Employ emp1 = new Employ(1001, "harry", 45000.25, "Java Developer", "Hyd");
		Employ emp2 = new Employ(1002, "lilly", 55000.25, "UI Developer", "Bang");
		Employ emp3 = new Employ(1003, "roja", 65000.25, "UX Designer", "Mumb");
		Employ emp4 = new Employ(1004, "sony", 95000.25, "HR Manager", "Chenn");
		Employ emp5 = new Employ(1005, "shiny", 75000.25, ".NET Developer", "Hyd");

		List<Employ> empList = Arrays.asList(emp1, emp2, emp3, emp4, emp5);

		List<Employ> hydEmpList = lw.findLocationWise(empList, "Hyd");

		System.out.println("---Hyd Employees--");

		for (Employ e : hydEmpList) {
			System.out.println(e);
		}

		List<Employ> bangEmpList = lw.findLocationWise(empList, "Bang");

		System.out.println("---Banglore Employees--");

		for (Employ e : bangEmpList) {
			System.out.println(e);
		}

	}
}
