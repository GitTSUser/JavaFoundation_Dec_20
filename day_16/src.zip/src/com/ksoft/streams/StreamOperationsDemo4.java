//program to demo implementation of in-built functional interfaces using Lambda expressions
package com.ksoft.streams;

import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

public class StreamOperationsDemo4 {

	public static void main(String[] args) {

		// implementation of Function interface using lambda expression
		Function<Integer, Integer> fun = (ele) -> {
			return ele * ele;
		};

		int squareOfNum = fun.apply(11);
		System.out.println("square of 11 is:" + squareOfNum);

		// implementation of BiFunction interface using lambda expression
		BiFunction<Integer, Integer, String> addFun = (a, b) -> {
			return "sum is:" + (a + b);
		};

		System.out.println(addFun.apply(100, 200));

		// implementation of Supplier interface using lambda expression
		Supplier<Integer> randomNumGenerator = () -> {
			return (int) (Math.random() * 100);
		};
		System.out.println("random no is:" + randomNumGenerator.get());
	}
}