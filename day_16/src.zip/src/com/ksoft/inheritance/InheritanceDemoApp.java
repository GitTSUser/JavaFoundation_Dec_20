//program to demonstrate inheritance from a class to another class
package com.ksoft.inheritance;

class Vehicle {

	String brand;
	String type;

	public Vehicle() {
	}

	public Vehicle(String brand, String type) {
		this.brand = brand;
		this.type = type;
	}

	public String vehicleInfo() {
		return this.brand + " " + this.type;
	}
}

class Bike extends Vehicle {

	String engineCapacity;

	public Bike(String brand, String type, String engineCapacity) {
		super(brand, type); // invokes the parent class constructor
		this.engineCapacity = engineCapacity;
	}

	public String bikeInfo() {
		// return this.brand + " " + this.type + " " + this.engineCapacity;
		return super.vehicleInfo() + " " + this.engineCapacity;
	}
}

public class InheritanceDemoApp {

	public static void main(String[] args) {

		Vehicle vehicle = new Vehicle("BMW", "automatic");
		System.out.println(vehicle.vehicleInfo());

		Bike bike = new Bike("Pulsar", "motor", "160cc");
		System.out.println(bike.bikeInfo());

	}
}