package com.ksoft.inheritance;
class Person {
	private String name;
	private int age;
	private Address address;

	public Person(String name, int age, Address address) {
		this.name = name;
		this.age = age;
		this.address = address;
	}

	public String personInfo() {

		return this.name + " " + this.age + " " + this.address.getHouseNo() + " " + this.address.getArea() + " "
				+ this.address.getCity() + " " + this.address.getPincode();
	}

}

class Address {

	private String houseNo;
	private String area;
	private String city;
	private int pincode;

	public Address(String houseNo, String area, String city, int pincode) {
		this.houseNo = houseNo;
		this.area = area;
		this.city = city;
		this.pincode = pincode;
	}

	public String getHouseNo() {
		return this.houseNo;
	}

	public String getArea() {
		return this.area;
	}

	public String getCity() {
		return this.city;
	}

	public int getPincode() {
		return this.pincode;
	}

}

public class HasARelationDemo {

	public static void main(String[] args) {

		Address address = new Address("12-2-46", "Manikonda", "Cyberabad", 500032);

		Person person = new Person("Meghana", 21, address);

		System.out.println(person.personInfo());

	}
}
