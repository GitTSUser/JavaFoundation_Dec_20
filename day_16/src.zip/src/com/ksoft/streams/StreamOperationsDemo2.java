//program to demo using streams find the sum of even elements of the array
package com.ksoft.streams;

import java.util.Arrays;
import java.util.stream.IntStream;

public class StreamOperationsDemo2 {

	public static void main(String[] args) {

		int numArr[] = { 10, 21, 30, 41, 50 };

		IntStream intStream = Arrays.stream(numArr); // IntStream on array we got
		IntStream evenStream = intStream.filter(e -> e % 2 == 0); // evenStream got on intStream
		int evenSum = evenStream.sum(); // invoking terminal operation sum

		System.out.println("even number sum is:" + evenSum);

		// we can also do everything in a line
		int es = Arrays.stream(numArr).filter(e -> e % 2 == 0).sum();
		System.out.println("even sum is:" + es);

	}

}
