//program to demonstrate using ArrayList to store any type of data
package com.ksoft.collections;

import java.util.ArrayList;

public class ArrayListDemo {

	static class Person {
		private String name;

		public Person(String name) {
			this.name = name;
		}

		public String getName() {
			return this.name;
		}
	}

	public static void main(String[] args) {
		ArrayList list = new ArrayList();

		list.add(120); // add integer
		list.add("Mani"); // add string
		list.add('k'); // add character
		list.add(4560.25); // add double
		list.add(true); // add boolean
		list.add(new Person("Suma")); // add an object

		// System.out.println(list);

		for (int i = 0; i < list.size(); i++) {
			if (list.get(i) instanceof Person) {
				Person p = (Person) list.get(i);
				System.out.println("element is:" + p.getName());

			} else {
				System.out.println("element is:" + list.get(i));
			}
		}

		// update elements in the list
		list.set(1, "Vijayani");
		System.out.println("after update , list is::");
		
		//print elements from the list		
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i) instanceof Person) {
				Person p = (Person) list.get(i);
				System.out.println("element is:" + p.getName());

			} else {
				System.out.println("element is:" + list.get(i));
			}
		}

		//remove an element from list		
		list.remove(5);
		System.out.println("----after removing person---");
		//print elements from the list
		for (int i = 0; i < list.size(); i++) {
					if (list.get(i) instanceof Person) {
						Person p = (Person) list.get(i);
						System.out.println("element is:" + p.getName());

					} else {
						System.out.println("element is:" + list.get(i));
					}
				}
		System.out.println("list size is:"+list.size());	
	}
}